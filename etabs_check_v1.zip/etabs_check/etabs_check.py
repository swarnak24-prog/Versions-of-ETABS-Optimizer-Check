"""ETABS model check - step 1 of a future beam/column size optimizer.

Usage:
    python etabs_check.py                     run the full check
    python etabs_check.py --test-connection   only connect, print version and model
    python etabs_check.py --gui               open the settings window
    python etabs_check.py --settings other.json

Exit codes: 0 = all checks pass, 2 = ran OK but some checks FAIL, 1 = error.
"""
import argparse
import logging
import os
import sys

import etabs_api as api
import report
import results
import sections
from config import SettingsError, default_settings, load_settings, validate_settings

log = logging.getLogger("etabs_check")
HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_SETTINGS_PATH = os.path.join(HERE, "settings.json")


def setup_logging(log_file=None, extra_handlers=()):
    log.setLevel(logging.DEBUG)
    log.propagate = False
    for h in list(log.handlers):
        log.removeHandler(h)
        if isinstance(h, logging.FileHandler):
            h.close()
    short = logging.Formatter("%(asctime)s %(levelname)-7s %(message)s", "%H:%M:%S")
    if sys.stdout:
        console = logging.StreamHandler(sys.stdout)
        console.setLevel(logging.INFO)
        console.setFormatter(short)
        log.addHandler(console)
    if log_file:
        fh = logging.FileHandler(log_file, encoding="utf-8")
        fh.setLevel(logging.DEBUG)  # file log includes every API call
        fh.setFormatter(logging.Formatter("%(asctime)s %(levelname)-7s %(message)s"))
        log.addHandler(fh)
    for h in extra_handlers:
        h.setLevel(logging.INFO)
        h.setFormatter(short)
        log.addHandler(h)


def test_connection(settings):
    session = api.connect(settings["attach_to_running"], settings["etabs_program_path"])
    version, number, model = api.get_version_and_model(session)
    log.info("Connected. ETABS version: %s (%s)", version, number)
    log.info("Model: %s", model)
    return version, model


def run_once(session, settings, run_folder):
    """One analyze -> design -> read -> report cycle on the model already open in ETABS.

    FUTURE: the optimizer loop will call this repeatedly, changing section
    assignments between calls (and stop when everything passes).
    """
    api.set_units(session, settings["units"])
    api.run_analysis(session, settings["drift"]["cases"])
    joint_rows, story_rows = results.get_drifts(session, settings["drift"])
    if settings["design"]["run"]:
        api.run_steel_design(session)
        design_rows = results.get_design_ratios(session, settings["design"]["group"])
    else:
        log.info("Steel frame design skipped (drift-only run).")
        design_rows = None
    return report.report(joint_rows, story_rows, design_rows, settings, run_folder)


def run_check(settings, extra_log_handlers=()):
    errors = validate_settings(settings)
    if errors:
        raise SettingsError("\n".join(errors))

    run_folder = api.make_run_folder(settings["output_folder"])
    setup_logging(os.path.join(run_folder, "run.log"), extra_log_handlers)
    log.info("Run folder: %s", run_folder)
    log.info("Original model (read only): %s", settings["model_path"])

    session = None
    try:
        session = api.connect(settings["attach_to_running"], settings["etabs_program_path"])
        copy_path = api.open_model_copy(session, settings["model_path"], run_folder)
        pools = sections.prepare_section_pools(session, settings["optimization"], run_folder)

        summary = run_once(session, settings, run_folder)
        # FUTURE optimization loop goes here, e.g.:
        #   while not summary["overall_pass"] and iteration < max_iterations:
        #       pick new sizes from pools["beam"] / pools["column"] and assign them
        #       summary = run_once(session, settings, run_folder)

        api.save_model(session, copy_path)
        summary["section_pools"] = pools or {}
        return summary
    finally:  # errors are logged by the caller (still written to run.log)
        if session:
            api.close(session, settings["close_etabs_when_done"])


def main(argv=None):
    p = argparse.ArgumentParser(description="Run an ETABS model and check drifts and steel D/C ratios.")
    p.add_argument("--settings", default=DEFAULT_SETTINGS_PATH, help="settings JSON file")
    p.add_argument("--test-connection", action="store_true", help="only connect and print version/model")
    p.add_argument("--gui", action="store_true", help="open the settings window")
    argv = sys.argv[1:] if argv is None else argv
    # Accept long dashes pasted from Word/Outlook/Teams ("–gui", "—gui") as "--gui"
    argv = ["--" + a.lstrip("–—-") if a[:1] in "–—" else a for a in argv]
    args = p.parse_args(argv)

    if args.gui:
        import gui
        gui.launch(args.settings)
        return 0

    setup_logging()
    try:
        if args.test_connection:
            settings = load_settings(args.settings) if os.path.isfile(args.settings) else default_settings()
            test_connection(settings)
            return 0
        settings = load_settings(args.settings)
        summary = run_check(settings)
        return 0 if summary["overall_pass"] else 2
    except SettingsError as e:
        log.error("Settings problem:\n%s", e)
    except api.EtabsError as e:
        log.error("%s", e)
    except Exception:
        log.exception("Unexpected error")
    return 1


if __name__ == "__main__":
    sys.exit(main())
