"""Read story drifts and steel design D/C ratios from the open ETABS model."""
import logging
import math

from etabs_api import EtabsError, check, name_list

log = logging.getLogger("etabs_check")

ITEM_OBJECT_ELM = 0     # eItemTypeElm.ObjectElm
ITEM_TYPE_GROUP = 1     # eItemType.Group
OBJ_TYPE_FRAME = 2      # object type code returned by GroupDef.GetAssignments
VERTICAL_TOL = 0.10     # member counts as a column if horizontal offset < 10% of its height

SHORT_RATIO_TYPES = {1: "PMM", 2: "V major", 3: "V minor", 4: "Major BC capacity",
                     5: "Minor BC capacity", 6: "Other"}


# ---------------------------------------------------------- output setup
def select_output_cases(session, names):
    """Select only the requested load cases / combos for results output."""
    m = session.model
    cases = set(name_list(m.LoadCases.GetNameList(0, []), "Get load case names"))
    combos = set(name_list(m.RespCombo.GetNameList(0, []), "Get load combination names"))
    check(m.Results.Setup.DeselectAllCasesAndCombosForOutput(), "Deselect all output cases")
    for name in names:
        if name in cases:
            check(m.Results.Setup.SetCaseSelectedForOutput(name), f"Select case '{name}' for output")
        elif name in combos:
            check(m.Results.Setup.SetComboSelectedForOutput(name), f"Select combo '{name}' for output")
        else:
            raise EtabsError(f"'{name}' is not a load case or combination in this model.")
    log.info("Selected for output: %s", ", ".join(names))


# ------------------------------------------------------- lateral columns
def _coords(m, point):
    r = check(m.PointObj.GetCoordCartesian(point, 0.0, 0.0, 0.0), f"Coordinates of joint {point}")
    return r[0], r[1], r[2]


def get_lateral_columns(session, group):
    """Vertical frame members in the lateral group, with their end joints and story."""
    m = session.model
    groups = name_list(m.GroupDef.GetNameList(0, []), "Get group names")
    if group not in groups:
        raise EtabsError(f"Group '{group}' not found in the model. Groups: {', '.join(groups)}")

    r = check(m.GroupDef.GetAssignments(group, 0, [], []), f"Get members of group '{group}'")
    count, types, names = r[0], r[1], r[2]
    frames = [names[i] for i in range(count) if types[i] == OBJ_TYPE_FRAME]

    columns = []
    all_points = set()  # every joint on any lateral beam or column
    for frame in frames:
        p = check(m.FrameObj.GetPoints(frame, "", ""), f"End joints of frame {frame}")
        all_points.update((p[0], p[1]))
        ends = [(p[0], _coords(m, p[0])), (p[1], _coords(m, p[1]))]
        ends.sort(key=lambda e: e[1][2])
        (bot, cb), (top, ct) = ends
        height = ct[2] - cb[2]
        horizontal = math.hypot(ct[0] - cb[0], ct[1] - cb[1])
        if height <= 0 or horizontal > VERTICAL_TOL * height:
            continue  # beam or brace: its joints are listed, drift comes from the column below
        story = check(m.PointObj.GetLabelFromName(top, "", ""), f"Story of joint {top}")[1]
        columns.append({"frame": frame, "bottom": bot, "top": top, "height": height,
                        "elevation": ct[2], "story": story})

    log.info("Group '%s': %d frame(s), %d column(s), %d joint(s).",
             group, len(frames), len(columns), len(all_points))
    if not columns:
        raise EtabsError(f"No vertical (column) members found in group '{group}'.")

    tops = {c["top"] for c in columns}
    bottoms = {c["bottom"] for c in columns}
    unpaired = sorted(all_points - tops - bottoms)
    if unpaired:
        log.warning("Joints on lateral beams with no lateral column below (no drift reported): %s",
                    ", ".join(unpaired))
    return columns


def _joint_displacements(m, point):
    """{(case, step type, step number): (Ux, Uy)} for one joint, for the selected cases."""
    r = check(m.Results.JointDispl(point, ITEM_OBJECT_ELM, 0, [], [], [], [], [],
                                   [], [], [], [], [], []),
              f"Joint displacements at {point}")
    count, case, step_type, step_num, u1, u2 = r[0], r[3], r[4], r[5], r[6], r[7]
    return {(case[i], step_type[i], round(step_num[i], 6)): (u1[i], u2[i]) for i in range(count)}


def _step_label(step_type, step_num):
    st = (step_type or "").strip()
    return st if st in ("Max", "Min", "") else f"{st} {step_num:g}"


# ---------------------------------------------------------------- drifts
def get_joint_drifts(session, cases, group):
    """Drift at every MF beam-column joint (top of each lateral-group column).

    drift = (U_joint - U_joint_below) / column height, same case and step,
    max over the selected cases, reported separately for X and Y.
    """
    m = session.model
    select_output_cases(session, cases)
    columns = get_lateral_columns(session, group)

    displ = {}
    joints = {}
    for col in columns:
        for pt in (col["top"], col["bottom"]):
            if pt not in displ:
                displ[pt] = _joint_displacements(m, pt)
        top, bot = displ[col["top"]], displ[col["bottom"]]
        row = joints.setdefault(col["top"], {
            "story": col["story"], "joint": col["top"], "joint_below": col["bottom"],
            "column": col["frame"], "elevation": col["elevation"], "height": col["height"],
            "drift_x": 0.0, "case_x": "", "step_x": "", "drift_y": 0.0, "case_y": "", "step_y": ""})
        for key, (ux_t, uy_t) in top.items():
            if key not in bot:
                continue
            ux_b, uy_b = bot[key]
            for axis, value in (("x", (ux_t - ux_b) / col["height"]),
                                ("y", (uy_t - uy_b) / col["height"])):
                if abs(value) > row[f"drift_{axis}"]:
                    row[f"drift_{axis}"] = abs(value)
                    row[f"case_{axis}"] = key[0]
                    row[f"step_{axis}"] = _step_label(key[1], key[2])

    rows = sorted(joints.values(), key=lambda r: (-r["elevation"], str(r["joint"])))
    log.info("Drifts computed at %d MF joint(s).", len(rows))
    return rows


def story_max_from_joints(joint_rows):
    """Max drift per story and direction, derived from the joint rows."""
    best = {}
    for j in joint_rows:
        for axis in ("x", "y"):
            k = (j["story"], axis.upper())
            if k not in best or j[f"drift_{axis}"] > best[k]["drift"]:
                best[k] = {"story": j["story"], "direction": axis.upper(), "drift": j[f"drift_{axis}"],
                           "case": j[f"case_{axis}"], "step": j[f"step_{axis}"], "frame": j["column"],
                           "joint": j["joint"], "elevation": j["elevation"], "height": j["height"]}
    return sorted(best.values(), key=lambda r: (-r["elevation"], r["direction"]))


def get_drifts_etabs(session, cases):
    """ETABS' built-in story drifts (all joints at each story, not only the lateral group)."""
    m = session.model
    select_output_cases(session, cases)
    r = check(m.Results.StoryDrifts(0, [], [], [], [], [], [], [], [], [], []), "Get story drifts")
    count, story, case, step_type, step_num, direction, drift = r[0], r[1], r[2], r[3], r[4], r[5], r[6]
    best, order = {}, {}
    for i in range(count):
        k = (story[i], direction[i])
        order.setdefault(story[i], len(order))
        if k not in best or abs(drift[i]) > best[k]["drift"]:
            best[k] = {"story": story[i], "direction": direction[i], "drift": abs(drift[i]),
                       "case": case[i], "step": _step_label(step_type[i], step_num[i]),
                       "frame": "", "joint": r[7][i], "elevation": "", "height": ""}
    rows = sorted(best.values(), key=lambda r: (order[r["story"]], r["direction"]))
    log.info("ETABS story drifts read for %d story/direction pair(s).", len(rows))
    return rows


def get_drifts(session, drift_settings):
    """Returns (joint_rows, story_rows). joint_rows is empty for the etabs_story_drifts method."""
    if drift_settings["method"] == "etabs_story_drifts":
        return [], get_drifts_etabs(session, drift_settings["cases"])
    joints = get_joint_drifts(session, drift_settings["cases"], drift_settings["lateral_group"])
    return joints, story_max_from_joints(joints)


# --------------------------------------------------------- design ratios
def _summary_results(design_steel, group):
    """Call DesignSteel.GetSummaryResults.

    UNSURE OF EXACT SIGNATURE: ETABS documents a long form (per-check ratios and combos);
    SAP2000-style builds use a short form. Both are tried. Confirm in the CSI API help:
    cDesignSteel > GetSummaryResults (CSI_OAPI_Documentation.chm in the ETABS folder).
    """
    attempts = (
        ("etabs", (group, 0, *[[] for _ in range(13)], ITEM_TYPE_GROUP), 15),
        ("short", (group, 0, *[[] for _ in range(7)], ITEM_TYPE_GROUP), 9),
    )
    last_error = None
    for fmt, args, expected_len in attempts:
        try:
            r = design_steel.GetSummaryResults(*args)
        except Exception as e:
            last_error = e
            log.debug("GetSummaryResults (%s form) raised: %s", fmt, e)
            continue
        if isinstance(r, (list, tuple)) and len(r) == expected_len:
            log.debug("GetSummaryResults matched the %s form.", fmt)
            return r, fmt
        log.debug("GetSummaryResults (%s form) returned an unexpected shape.", fmt)
    raise EtabsError("Could not read steel design results with either known GetSummaryResults "
                     "signature. See cDesignSteel > GetSummaryResults in CSI_OAPI_Documentation.chm.") \
        from last_error


def get_design_ratios(session, group="All"):
    """Governing steel D/C ratio and combo for each designed frame in the group."""
    r, fmt = _summary_results(session.model.DesignSteel, group)
    check(r, "Get steel design summary results (was steel design run?)")
    rows = []
    if fmt == "etabs":
        (count, frames, _ftype, sections, status, pmm_combo, pmm,
         _p, _mmaj, _mmin, vmaj_combo, vmaj, vmin_combo, vmin) = r[:14]
        for i in range(count):
            checks = [("PMM", pmm[i], pmm_combo[i]),
                      ("V major", vmaj[i], vmaj_combo[i]),
                      ("V minor", vmin[i], vmin_combo[i])]
            kind, ratio, combo = max(checks, key=lambda c: c[1])
            rows.append({"frame": frames[i], "section": sections[i], "ratio": ratio,
                         "ratio_type": kind, "combo": combo, "message": status[i]})
    else:
        count, frames, ratio, rtype, _loc, combo, err, warn = r[:8]
        for i in range(count):
            rows.append({"frame": frames[i], "section": "", "ratio": ratio[i],
                         "ratio_type": SHORT_RATIO_TYPES.get(rtype[i], str(rtype[i])),
                         "combo": combo[i], "message": f"{err[i]} {warn[i]}".strip()})
    rows.sort(key=lambda row: -row["ratio"])
    log.info("Steel design results read for %d frame(s).", len(rows))
    return rows
