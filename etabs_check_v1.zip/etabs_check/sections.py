"""Section pools for the optimizer.

Reads the AISC shape library that ships with ETABS, keeps the W shapes in the
beam and column series the user checked, and imports any missing ones into the
open model (always the COPY). Writes section_pool.csv.

API calls used (cPropFrame in CSI_OAPI_Documentation.chm):
  GetPropFileNameList(FileName, NumberNames, MyName, MyType, [PropType])
  ImportProp(Name, MatProp, FileName, PropName, [Color, Notes, GUID])
UNSURE: whether ETABS finds the library from the bare file name (e.g. "AISC16.xml").
The CSI docs say a bare name usually works but a full path is sometimes needed;
if the run says the library is empty or missing, browse to the file in the ETABS
install folder (look for AISC16.xml or AISC15.xml).
"""
import csv
import logging
import os
import re

from etabs_api import EtabsError, check, name_list

log = logging.getLogger("etabs_check")

_W_SHAPE = re.compile(r"^(W\d+)X(\d+(?:\.\d+)?)$", re.IGNORECASE)


def parse_w_shape(name):
    """'W14X90' -> ('W14', 90.0); anything else -> None."""
    m = _W_SHAPE.match(str(name).strip())
    return (m.group(1).upper(), float(m.group(2))) if m else None


def filter_by_series(names, series):
    """Shapes from `names` in the given series, lightest first: [(name, series, weight plf)]."""
    wanted = {s.upper() for s in series}
    found = {}
    for n in names:
        parsed = parse_w_shape(n)
        if parsed and parsed[0] in wanted:
            found[n] = (n, parsed[0], parsed[1])
    return sorted(found.values(), key=lambda t: (t[2], t[0]))


def list_library_shapes(session, section_file):
    r = session.model.PropFrame.GetPropFileNameList(section_file, 0, [], [])
    names = name_list([r[0], r[1], r[-1]], f"Read section library '{section_file}'")
    log.info("Section library '%s': %d shapes.", section_file, len(names))
    return names


def prepare_section_pools(session, optimization, run_folder):
    """Import the checked series into the model copy. Returns {"beam": [...], "column": [...]} or None."""
    beam_series = optimization.get("beam_series") or []
    column_series = optimization.get("column_series") or []
    if not beam_series and not column_series:
        log.info("No beam or column series selected; skipping optimization section pools.")
        return None

    m = session.model
    material = optimization["steel_material"]
    section_file = optimization["section_file"]

    materials = name_list(m.PropMaterial.GetNameList(0, []), "Get material names")
    if material not in materials:
        raise EtabsError(f"Steel material '{material}' is not defined in the model. "
                         f"Materials: {', '.join(materials)}")

    library = list_library_shapes(session, section_file)
    if not library:
        raise EtabsError(f"Section library '{section_file}' returned no shapes. Browse to the full "
                         "path of the file in the ETABS install folder (e.g. AISC16.xml).")

    if m.GetModelIsLocked():
        check(m.SetModelIsLocked(False), "Unlock model to add sections")
    existing = set(name_list(m.PropFrame.GetNameList(0, []), "Get frame section names"))

    pools, rows = {}, []
    for role, series in (("beam", beam_series), ("column", column_series)):
        shapes = filter_by_series(library, series)
        missing = sorted(set(series) - {s for _, s, _ in shapes})
        if missing:
            log.warning("No %s shapes found in the library for series: %s", role, ", ".join(missing))
        pool = []
        for name, ser, weight in shapes:
            if name in existing:
                status = "already in model"
            else:
                try:
                    check(m.PropFrame.ImportProp(name, material, section_file, name), f"Import section {name}")
                    existing.add(name)
                    status = "imported"
                except EtabsError:
                    status = "import failed"
            if status != "import failed":
                pool.append(name)
            rows.append({"role": role, "series": ser, "shape": name, "weight_plf": weight, "status": status})
        pools[role] = pool
        if pool:
            log.info("%s pool: %d shapes from %s (lightest %s, heaviest %s).", role.capitalize(),
                     len(pool), ", ".join(series), pool[0], pool[-1])

    n_imported = sum(r["status"] == "imported" for r in rows)
    n_failed = sum(r["status"] == "import failed" for r in rows)
    log.info("Sections imported into the model copy: %d (failed: %d).", n_imported, n_failed)

    path = os.path.join(run_folder, "section_pool.csv")
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["role", "series", "shape", "weight_plf", "status"])
        w.writeheader()
        w.writerows(rows)
    log.info("Saved %s", path)
    return pools
