"""Thin wrappers around the CSI ETABS API (COM, through comtypes).

comtypes convention used throughout: methods with output ("ref") arguments
return a list of those outputs with the ETABS return code LAST.
Methods with no outputs return just the return code. 0 = success.
"""
import datetime
import logging
import os
import shutil

from config import UNIT_CODES

log = logging.getLogger("etabs_check")

HELPER_PROGID = "ETABSv1.Helper"
ETABS_PROGID = "CSI.ETABS.API.ETABSObject"
CASE_STATUS = {1: "Not run", 2: "Could not start", 3: "Not finished", 4: "Finished"}


class EtabsError(Exception):
    """Any failure talking to ETABS. The message includes the return code."""


def ret_code(result):
    if isinstance(result, (list, tuple)):
        return result[-1] if result else -1
    return result


def check(result, what):
    """Raise EtabsError if an API call returned a non-zero code; else pass the result through."""
    code = ret_code(result)
    if code != 0:
        log.error("API call failed: %s (return code %s)", what, code)
        raise EtabsError(f"{what} failed (ETABS return code {code})")
    log.debug("OK: %s", what)
    return result


def name_list(result, what):
    """Unpack a [count, names, ret] result into a Python list."""
    check(result, what)
    count = result[0]
    return list(result[1])[:count] if count else []


class EtabsSession:
    def __init__(self, etabs_object, started_by_us):
        self.etabs = etabs_object
        self.model = etabs_object.SapModel
        self.started_by_us = started_by_us


# ---------------------------------------------------------------- connect
def connect(attach_to_running=True, program_path=""):
    """Attach to a running ETABS, or start one. Returns an EtabsSession."""
    try:
        import comtypes.client
    except ImportError as e:
        raise EtabsError("comtypes is not installed. Run: python -m pip install comtypes") from e

    log.info("Creating ETABS API helper (%s)", HELPER_PROGID)
    try:
        helper = comtypes.client.CreateObject(HELPER_PROGID)
        from comtypes.gen import ETABSv1
        helper = helper.QueryInterface(ETABSv1.cHelper)
    except Exception as e:
        raise EtabsError(
            "ETABS not found: could not create the ETABS API helper. Check that ETABS "
            "(v18 or later) is installed, that you are using 64-bit Python, and that the "
            "API is registered (run RegisterETABS.exe from the ETABS install folder as "
            f"administrator). Details: {e}") from e

    if attach_to_running:
        try:
            etabs = helper.GetObject(ETABS_PROGID)
            log.info("Attached to running ETABS instance.")
            return EtabsSession(etabs, started_by_us=False)
        except Exception:
            log.info("No running ETABS instance found; starting a new one.")

    try:
        if program_path:
            log.info("Starting ETABS from %s", program_path)
            etabs = helper.CreateObject(program_path)
        else:
            log.info("Starting the latest installed ETABS")
            etabs = helper.CreateObjectProgID(ETABS_PROGID)
    except Exception as e:
        raise EtabsError(f"ETABS not found: could not start ETABS. Details: {e}") from e

    check(etabs.ApplicationStart(), "Start ETABS")
    log.info("ETABS started.")
    return EtabsSession(etabs, started_by_us=True)


def get_version_and_model(session):
    result = check(session.model.GetVersion(), "Get ETABS version")
    version, number = result[0], result[1]
    model_name = session.model.GetModelFilename(True) or "(no model open)"
    return version, number, model_name


def close(session, close_if_started=False):
    if session.started_by_us and close_if_started:
        log.info("Closing ETABS (it was started by this program).")
        try:
            session.etabs.ApplicationExit(False)
        except Exception as e:
            log.warning("Could not close ETABS cleanly: %s", e)


# ------------------------------------------------------------- open model
def make_run_folder(output_folder):
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    path = os.path.join(output_folder, f"run_{stamp}")
    os.makedirs(path, exist_ok=True)
    return path


def _same_file(a, b):
    return os.path.normcase(os.path.abspath(a)) == os.path.normcase(os.path.abspath(b))


def open_model_copy(session, original_path, run_folder):
    """Copy the model into the run folder and open the COPY. The original is never touched."""
    original = os.path.abspath(original_path)
    if not os.path.isfile(original):
        raise EtabsError(f"Model file not found: {original}")
    if not original.lower().endswith(".edb"):
        log.warning("Model is not an .edb file; ETABS will import it. Saving as .edb is recommended.")

    current = session.model.GetModelFilename(True) or ""
    if current and _same_file(current, original):
        log.warning("ETABS currently has the ORIGINAL model open. Save any unsaved work in ETABS; "
                    "this program will switch ETABS to the copy.")

    copy_path = os.path.join(run_folder, os.path.basename(original))
    try:
        shutil.copy2(original, copy_path)
    except PermissionError as e:
        raise EtabsError(f"Model locked: could not copy {original} (file in use or no permission).") from e
    log.info("Copied model to %s", copy_path)

    check(session.model.File.OpenFile(copy_path), f"Open model copy {copy_path}")
    opened = session.model.GetModelFilename(True) or ""
    if not opened.lower().endswith(".edb") or not _same_file(os.path.splitext(opened)[0],
                                                            os.path.splitext(copy_path)[0]):
        raise EtabsError(f"ETABS did not open the copy as expected (open file: {opened}). Stopping "
                         "to protect the original model.")
    log.info("Opened copy: %s", opened)
    return opened


def save_model(session, path):
    check(session.model.File.Save(path), f"Save model copy {path}")
    log.info("Saved analyzed copy: %s", path)


# ----------------------------------------------------------------- setup
def set_units(session, units):
    check(session.model.SetPresentUnits(UNIT_CODES[units]), f"Set units to {units}")
    log.info("Units set to %s", units)


# -------------------------------------------------------------- analysis
def case_status(session):
    r = check(session.model.Analyze.GetCaseStatus(0, [], []), "Get analysis case status")
    count, names, status = r[0], r[1], r[2]
    return {names[i]: status[i] for i in range(count)}


def run_analysis(session, required_names=()):
    m = session.model
    if m.GetModelIsLocked():
        log.info("Model copy is locked (old results); unlocking it.")
        check(m.SetModelIsLocked(False), "Unlock model")
    check(m.Analyze.SetRunCaseFlag("", True, True), "Set all load cases to run")
    log.info("Running analysis ...")
    check(m.Analyze.RunAnalysis(), "Run analysis")

    status = case_status(session)
    problems = {c: s for c, s in status.items() if s != 4}
    for c, s in problems.items():
        log.warning("Load case '%s': %s", c, CASE_STATUS.get(s, s))
    failed_required = [n for n in required_names if n in problems]
    if failed_required or (status and len(problems) == len(status)):
        raise EtabsError("Analysis failed: these cases did not finish: "
                         + ", ".join(failed_required or problems))
    log.info("Analysis finished (%d cases).", len(status))


def run_steel_design(session):
    m = session.model
    try:
        code = check(m.DesignSteel.GetCode(""), "Get steel design code")[0]
        log.info("Steel design code: %s", code)
    except EtabsError:
        log.warning("Could not read the steel design code (continuing).")
    log.info("Running steel frame design ...")
    check(m.DesignSteel.StartDesign(), "Run steel frame design")
    log.info("Steel frame design finished.")
