"""Tkinter window: edit settings, save them, test the connection, and run the check."""
import json
import logging
import logging.handlers
import os
import queue
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk

import etabs_check as app
import report
from config import (DRIFT_METHODS, UNIT_CODES, W_SERIES, SettingsError, default_settings,
                    load_settings, save_settings, validate_settings)

log = logging.getLogger("etabs_check")


class App(tk.Tk):
    def __init__(self, settings_path):
        super().__init__()
        self.title("ETABS Model Check")
        self.geometry("840x880")
        self.settings_path = settings_path
        self.settings = default_settings()
        self.log_queue = queue.Queue()
        self.result_queue = queue.Queue()
        self.queue_handler = logging.handlers.QueueHandler(self.log_queue)
        self.vars = {}
        self._build()
        self.load()
        self.after(100, self._poll)

    # ------------------------------------------------------------ layout
    def _build(self):
        form = ttk.Frame(self, padding=10)
        form.pack(fill="x")
        form.columnconfigure(1, weight=1)
        row = 0

        def add(label, key, widget=None, browse=None):
            nonlocal row
            ttk.Label(form, text=label).grid(row=row, column=0, sticky="w", pady=2)
            var = tk.StringVar()
            self.vars[key] = var
            w = widget(form, var) if widget else ttk.Entry(form, textvariable=var)
            w.grid(row=row, column=1, sticky="ew", pady=2)
            if browse:
                ttk.Button(form, text="Browse...", command=browse).grid(row=row, column=2, padx=4)
            row += 1

        combo = lambda values: (lambda parent, var: ttk.Combobox(parent, textvariable=var,
                                                                values=values, state="readonly"))
        add("Model file (.edb)", "model_path", browse=self.browse_model)
        add("Output folder", "output_folder", browse=self.browse_output)
        add("Units", "units", combo(list(UNIT_CODES)))
        add("Drift limit (e.g. 0.020)", "drift_limit")
        add("Drift cases/combos (comma separated)", "drift_cases")
        add("Lateral group name", "lateral_group")
        add("Drift method", "drift_method", combo(list(DRIFT_METHODS)))
        add("Allowable D/C ratio", "allowable_ratio")
        add("Design group (All = every frame)", "design_group")

        self.attach_var = tk.BooleanVar()
        self.close_var = tk.BooleanVar()
        self.design_var = tk.BooleanVar()
        ttk.Checkbutton(form, text="Run steel frame design (uncheck for a faster drift-only run)",
                        variable=self.design_var).grid(row=row, column=1, sticky="w")
        row += 1
        ttk.Checkbutton(form, text="Attach to running ETABS if open",
                        variable=self.attach_var).grid(row=row, column=1, sticky="w")
        row += 1
        ttk.Checkbutton(form, text="Close ETABS when done (only if this program started it)",
                        variable=self.close_var).grid(row=row, column=1, sticky="w")
        row += 1

        ttk.Separator(form).grid(row=row, column=0, columnspan=3, sticky="ew", pady=8)
        row += 1
        ttk.Label(form, text="OPTIMIZATION SECTIONS (W shapes imported from the ETABS AISC library)",
                  font=("Segoe UI", 9, "bold")).grid(row=row, column=0, columnspan=3, sticky="w")
        row += 1
        ttk.Label(form, text="Beam series").grid(row=row, column=0, sticky="w", pady=2)
        self.beam_series = SeriesDropdown(form, W_SERIES, "Beam series")
        self.beam_series.grid(row=row, column=1, sticky="ew", pady=2)
        row += 1
        ttk.Label(form, text="Column series").grid(row=row, column=0, sticky="w", pady=2)
        self.column_series = SeriesDropdown(form, W_SERIES, "Column series")
        self.column_series.grid(row=row, column=1, sticky="ew", pady=2)
        row += 1
        add("Section library file", "section_file", browse=self.browse_section_file)
        add("Steel material for imported shapes", "steel_material")

        buttons = ttk.Frame(self, padding=(10, 0))
        buttons.pack(fill="x")
        self.button_widgets = []
        for text, cmd in (("Load settings", self.load), ("Save settings", self.save),
                          ("Test connection", self.test_connection), ("Run", self.run)):
            b = ttk.Button(buttons, text=text, command=cmd)
            b.pack(side="left", padx=4, pady=8)
            self.button_widgets.append(b)

        self.log_box = scrolledtext.ScrolledText(self, height=20, font=("Consolas", 9), state="disabled")
        self.log_box.pack(fill="both", expand=True, padx=10, pady=(0, 10))

    # ------------------------------------------------- settings <-> form
    def browse_model(self):
        path = filedialog.askopenfilename(title="Select ETABS model",
                                          filetypes=[("ETABS model", "*.edb"), ("All files", "*.*")])
        if path:
            self.vars["model_path"].set(path)

    def browse_section_file(self):
        path = filedialog.askopenfilename(
            title="Select ETABS section library (e.g. AISC16.xml in the ETABS folder)",
            initialdir=r"C:\Program Files\Computers and Structures",
            filetypes=[("Section library", "*.xml *.pro"), ("All files", "*.*")])
        if path:
            self.vars["section_file"].set(path)

    def browse_output(self):
        path = filedialog.askdirectory(title="Select output folder")
        if path:
            self.vars["output_folder"].set(path)

    def to_form(self, s):
        v = self.vars
        v["model_path"].set(s["model_path"])
        v["output_folder"].set(s["output_folder"])
        v["units"].set(s["units"])
        v["drift_limit"].set(str(s["drift"]["limit"]))
        v["drift_cases"].set(", ".join(s["drift"]["cases"]))
        v["lateral_group"].set(s["drift"]["lateral_group"])
        v["drift_method"].set(s["drift"]["method"])
        v["allowable_ratio"].set(str(s["design"]["allowable_ratio"]))
        v["design_group"].set(s["design"]["group"])
        self.attach_var.set(bool(s["attach_to_running"]))
        self.close_var.set(bool(s["close_etabs_when_done"]))
        self.design_var.set(bool(s["design"]["run"]))
        opt = s["optimization"]
        self.beam_series.set(opt["beam_series"])
        self.column_series.set(opt["column_series"])
        v["section_file"].set(opt["section_file"])
        v["steel_material"].set(opt["steel_material"])

    def from_form(self):
        """Build a settings dict from the form. Raises SettingsError on unparseable input."""
        v = self.vars
        s = json.loads(json.dumps(self.settings))  # keep keys the form doesn't show
        s["model_path"] = v["model_path"].get().strip()
        s["output_folder"] = v["output_folder"].get().strip()
        s["units"] = v["units"].get()
        s["attach_to_running"] = self.attach_var.get()
        s["close_etabs_when_done"] = self.close_var.get()
        try:
            s["drift"]["limit"] = float(v["drift_limit"].get())
            s["design"]["allowable_ratio"] = float(v["allowable_ratio"].get())
        except ValueError:
            raise SettingsError("Drift limit and allowable ratio must be numbers.")
        s["drift"]["cases"] = [c.strip() for c in v["drift_cases"].get().split(",") if c.strip()]
        s["drift"]["lateral_group"] = v["lateral_group"].get().strip()
        s["drift"]["method"] = v["drift_method"].get()
        s["design"]["group"] = v["design_group"].get().strip()
        s["design"]["run"] = self.design_var.get()
        s.pop("frame_groups", None)  # replaced by the optimization series below
        s["optimization"] = {"beam_series": self.beam_series.get(),
                             "column_series": self.column_series.get(),
                             "section_file": v["section_file"].get().strip(),
                             "steel_material": v["steel_material"].get().strip()}
        return s

    def load(self):
        try:
            if os.path.isfile(self.settings_path):
                self.settings = load_settings(self.settings_path)
                self._write(f"Loaded {self.settings_path}")
            else:
                self._write(f"No settings file yet; using defaults ({self.settings_path} will be created on save).")
        except SettingsError as e:
            messagebox.showerror("Settings", str(e))
        self.to_form(self.settings)

    def save(self, quiet=False):
        try:
            s = self.from_form()
        except SettingsError as e:
            messagebox.showerror("Settings", str(e))
            return None
        save_settings(s, self.settings_path)
        self.settings = s
        if not quiet:
            self._write(f"Saved {self.settings_path}")
        return s

    # ------------------------------------------------------------ actions
    def test_connection(self):
        s = self.save(quiet=True)
        if s is not None:
            self._start(lambda: (app.setup_logging(extra_handlers=[self.queue_handler]),
                                 app.test_connection(s)))

    def run(self):
        s = self.save(quiet=True)
        if s is None:
            return
        errors = validate_settings(s)
        if errors:
            messagebox.showerror("Settings", "\n".join(errors))
            return
        self._write("Settings saved. Starting run ...")
        self._start(lambda: app.run_check(s, extra_log_handlers=[self.queue_handler]))

    def _start(self, job):
        for b in self.button_widgets:
            b.state(["disabled"])

        def worker():
            try:
                import comtypes
                comtypes.CoInitialize()  # COM must be initialized on this thread
            except ImportError:
                self.result_queue.put(("error", "comtypes is not installed (python -m pip install comtypes)."))
                return
            try:
                self.result_queue.put(("done", job()))
            except Exception as e:
                log.error("%s", e)
                self.result_queue.put(("error", str(e)))
            finally:
                comtypes.CoUninitialize()

        threading.Thread(target=worker, daemon=True).start()

    # ----------------------------------------------------------- plumbing
    def _write(self, text):
        self.log_box.configure(state="normal")
        self.log_box.insert("end", text + "\n")
        self.log_box.see("end")
        self.log_box.configure(state="disabled")

    def _poll(self):
        while not self.log_queue.empty():
            self._write(self.log_queue.get().getMessage())
        while not self.result_queue.empty():
            kind, value = self.result_queue.get()
            for b in self.button_widgets:
                b.state(["!disabled"])
            if kind == "error":
                messagebox.showerror("ETABS check", value)
            elif isinstance(value, dict) and "overall_pass" in value:
                ResultsWindow(self, value)
        self.after(100, self._poll)


class SeriesDropdown(ttk.Frame):
    """A button that drops down a checklist of series; shows the current selection."""

    def __init__(self, parent, options, title):
        super().__init__(parent)
        self.options, self.title = options, title
        self.vars = {o: tk.BooleanVar() for o in options}
        self.popup = None
        self.button = ttk.Button(self, command=self.toggle)
        self.button.pack(fill="x")
        self._refresh()

    def get(self):
        return [o for o in self.options if self.vars[o].get()]

    def set(self, values):
        for o, var in self.vars.items():
            var.set(o in values)
        self._refresh()

    def _refresh(self):
        sel = self.get()
        text = ", ".join(sel) if sel else "(none selected)"
        if len(text) > 60:
            text = f"{len(sel)} series: {sel[0]} ... {sel[-1]}"
        self.button.configure(text=f"{text}   ▾")

    def toggle(self):
        if self.popup is not None and self.popup.winfo_exists():
            self.close()
            return
        p = tk.Toplevel(self)
        p.title(self.title)
        p.transient(self.winfo_toplevel())
        p.resizable(False, False)
        p.geometry(f"+{self.button.winfo_rootx()}+{self.button.winfo_rooty() + self.button.winfo_height()}")
        p.protocol("WM_DELETE_WINDOW", self.close)
        box = ttk.Frame(p, padding=10)
        box.pack(fill="both")
        per_col = 6
        for i, o in enumerate(self.options):
            ttk.Checkbutton(box, text=o, variable=self.vars[o], command=self._refresh
                            ).grid(row=i % per_col, column=i // per_col, sticky="w", padx=6, pady=1)
        bar = ttk.Frame(p, padding=(10, 0, 10, 10))
        bar.pack(fill="x")
        ttk.Button(bar, text="All", command=lambda: self.set(self.options)).pack(side="left")
        ttk.Button(bar, text="None", command=lambda: self.set([])).pack(side="left", padx=4)
        ttk.Button(bar, text="Done", command=self.close).pack(side="right")
        self.popup = p

    def close(self):
        if self.popup is not None and self.popup.winfo_exists():
            self.popup.destroy()
        self.popup = None
        self._refresh()


class ResultsWindow(tk.Toplevel):
    """Table of drift at each MF joint, PASS/FAIL against the limit, with CSV export."""

    COLUMNS = (("story", "Story", 90), ("joint", "Joint", 70), ("column", "Column below", 95),
               ("drift_x", "Drift X", 85), ("case_x", "Case X", 110),
               ("drift_y", "Drift Y", 85), ("case_y", "Case Y", 110),
               ("ratio_to_limit", "Max / Limit", 85), ("status", "Status", 70))

    def __init__(self, parent, summary):
        super().__init__(parent)
        self.title("Drift Results")
        self.geometry("900x520")
        self.summary = summary
        self.rows = summary["joint_rows"]
        limit = summary["drift_limit"]

        n_fail, n = summary["drift_fail_count"], summary["drift_check_count"]
        verdict = "ALL JOINTS PASS" if n_fail == 0 else f"{n_fail} OF {n} JOINTS FAIL"
        head = ttk.Frame(self, padding=10)
        head.pack(fill="x")
        ttk.Label(head, text=verdict, font=("Segoe UI", 14, "bold"),
                  foreground="#1a7f37" if n_fail == 0 else "#c62828").pack(anchor="w")
        ttk.Label(head, text=f"Drift limit {limit:.4f}   |   Max drift {summary['max_drift']:.5f}"
                             f"   |   Results folder: {summary['run_folder']}").pack(anchor="w")
        pools = summary.get("section_pools") or {}
        if pools:
            ttk.Label(head, text=f"Optimization pools imported: {len(pools.get('beam', []))} beam shapes, "
                                 f"{len(pools.get('column', []))} column shapes (see section_pool.csv)"
                      ).pack(anchor="w")

        body = ttk.Frame(self, padding=(10, 0))
        body.pack(fill="both", expand=True)
        if not self.rows:
            ttk.Label(body, text="No joint-level results: the 'etabs_story_drifts' method reports "
                                 "per story only. Switch Drift method to 'lateral_joints' to see MF joints.",
                      wraplength=820).pack(anchor="w", pady=20)
        else:
            tree = ttk.Treeview(body, columns=[c[0] for c in self.COLUMNS], show="headings")
            for key, title, width in self.COLUMNS:
                tree.heading(key, text=title)
                tree.column(key, width=width, anchor="center")
            tree.tag_configure("FAIL", background="#fde2e2", foreground="#9b1c1c")
            for r in self.rows:
                tree.insert("", "end", tags=(r["status"],), values=(
                    r["story"], r["joint"], r["column"],
                    f"{r['drift_x']:.5f}", r["case_x"], f"{r['drift_y']:.5f}", r["case_y"],
                    f"{r['ratio_to_limit']:.2f}", r["status"]))
            scroll = ttk.Scrollbar(body, orient="vertical", command=tree.yview)
            tree.configure(yscrollcommand=scroll.set)
            tree.pack(side="left", fill="both", expand=True)
            scroll.pack(side="right", fill="y")

        buttons = ttk.Frame(self, padding=10)
        buttons.pack(fill="x")
        ttk.Button(buttons, text="Export CSV...", command=self.export,
                   state="normal" if self.rows else "disabled").pack(side="left", padx=4)
        ttk.Button(buttons, text="Open results folder", command=self.open_folder).pack(side="left", padx=4)
        ttk.Button(buttons, text="Close", command=self.destroy).pack(side="right", padx=4)

    def export(self):
        path = filedialog.asksaveasfilename(parent=self, title="Export joint drifts",
                                            defaultextension=".csv", initialfile="joint_drifts.csv",
                                            initialdir=self.summary["run_folder"],
                                            filetypes=[("CSV file", "*.csv")])
        if path:
            try:
                report.write_joint_csv(self.rows, path)
                messagebox.showinfo("Export", f"Saved:\n{path}", parent=self)
            except PermissionError:
                messagebox.showerror("Export", "Could not save; is that file open in Excel?", parent=self)

    def open_folder(self):
        try:
            os.startfile(self.summary["run_folder"])  # Windows only
        except (AttributeError, OSError) as e:
            messagebox.showerror("Open folder", str(e), parent=self)


def launch(settings_path):
    App(settings_path).mainloop()


if __name__ == "__main__":
    launch(app.DEFAULT_SETTINGS_PATH)
