"""Load, validate and save the settings file.

Format: JSON (built into Python, so no extra package is needed).
"""
import copy
import json
import os

# ETABS eUnits enumeration values
UNIT_CODES = {"kip_in": 3, "kip_ft": 4}  # kip_in_F = 3, kip_ft_F = 4

DRIFT_METHODS = ("lateral_joints", "etabs_story_drifts")
# AISC W-shape series (nominal depth) offered for the optimizer
W_SERIES = ["W4", "W5", "W6", "W8", "W10", "W12", "W14", "W16", "W18", "W21",
            "W24", "W27", "W30", "W33", "W36", "W40", "W44"]
START_FROM = ("current", "lightest")
MODEL_EXTENSIONS = (".edb", ".e2k", ".$et")

DEFAULT_SETTINGS = {
    "model_path": "",
    "output_folder": "C:/ETABS-Check/runs",
    "units": "kip_in",
    "attach_to_running": True,
    "etabs_program_path": "",
    "close_etabs_when_done": False,
    "drift": {
        "limit": 0.020,
        "cases": [],
        "lateral_group": "Lateral",
        "method": "lateral_joints",
    },
    "design": {
        "run": True,
        "allowable_ratio": 1.0,
        "group": "All",
    },
    "optimization": {
        "beam_series": ["W18", "W21", "W24"],
        "column_series": ["W14"],
        "section_file": "AISC16.xml",
        "steel_material": "A992Fy50",
        "enabled": False,
        "split_by_direction": False,
        "column_stories_per_group": 1,
        "start_from": "current",
        "max_analyses": 50,
        "column_depth_rule": False,
        "hide_etabs": True,
    },
}


class SettingsError(Exception):
    """Raised when the settings file is missing, unreadable or invalid."""


def _merge(defaults, user):
    """Fill in any keys the user's file leaves out with defaults."""
    out = copy.deepcopy(defaults)
    for key, value in user.items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _merge(out[key], value)
        else:
            out[key] = value
    return out


def default_settings():
    return copy.deepcopy(DEFAULT_SETTINGS)


def load_settings(path):
    if not os.path.isfile(path):
        raise SettingsError(f"Settings file not found: {path}")
    with open(path, "r", encoding="utf-8") as f:
        try:
            data = json.load(f)
        except json.JSONDecodeError as e:
            raise SettingsError(f"Settings file is not valid JSON: {e}") from e
    if not isinstance(data, dict):
        raise SettingsError("Settings file must contain a JSON object { ... }.")
    return _merge(DEFAULT_SETTINGS, data)


def save_settings(settings, path):
    folder = os.path.dirname(os.path.abspath(path))
    os.makedirs(folder, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(settings, f, indent=2)


def _is_name_list(value):
    return (isinstance(value, list) and len(value) > 0
            and all(isinstance(v, str) and v.strip() for v in value))


def validate_settings(s, require_model=True):
    """Return a list of human-readable problems (empty list = valid)."""
    errors = []

    model = s.get("model_path", "")
    if require_model:
        if not model:
            errors.append("model_path is empty.")
        elif not os.path.isfile(model):
            errors.append(f"model_path does not exist: {model}")
        elif not model.lower().endswith(MODEL_EXTENSIONS):
            errors.append("model_path must be an ETABS model file (.edb).")

    if not s.get("output_folder"):
        errors.append("output_folder is empty.")

    if s.get("units") not in UNIT_CODES:
        errors.append(f"units must be one of {list(UNIT_CODES)}.")

    prog = s.get("etabs_program_path", "")
    if prog and not os.path.isfile(prog):
        errors.append(f"etabs_program_path does not exist: {prog}")

    drift = s.get("drift", {})
    try:
        limit = float(drift.get("limit"))
        if not 0 < limit < 1:
            errors.append("drift.limit should be a ratio between 0 and 1 (e.g. 0.020).")
    except (TypeError, ValueError):
        errors.append("drift.limit must be a number (e.g. 0.020).")
    if not _is_name_list(drift.get("cases")):
        errors.append("drift.cases must list at least one load case or combo name.")
    if not str(drift.get("lateral_group", "")).strip():
        errors.append("drift.lateral_group is empty (e.g. \"Lateral\").")
    if drift.get("method") not in DRIFT_METHODS:
        errors.append(f"drift.method must be one of {list(DRIFT_METHODS)}.")

    design = s.get("design", {})
    if not isinstance(design.get("run"), bool):
        errors.append("design.run must be true or false.")
    try:
        ratio = float(design.get("allowable_ratio"))
        if ratio <= 0:
            errors.append("design.allowable_ratio must be greater than 0.")
    except (TypeError, ValueError):
        errors.append("design.allowable_ratio must be a number (e.g. 1.0).")
    if not str(design.get("group", "")).strip():
        errors.append("design.group is empty (use \"All\" for every frame).")

    opt = s.get("optimization", {})
    for key in ("beam_series", "column_series"):
        series = opt.get(key)
        if not isinstance(series, list):
            errors.append(f"optimization.{key} must be a list, e.g. [\"W14\"].")
            continue
        unknown = [x for x in series if x not in W_SERIES]
        if unknown:
            errors.append(f"optimization.{key}: unknown series {unknown}. Choose from {W_SERIES}.")
    if opt.get("enabled") and not (opt.get("beam_series") or opt.get("column_series")):
        errors.append("Optimization is on but no beam or column series is selected.")
    for key in ("enabled", "split_by_direction", "column_depth_rule", "hide_etabs"):
        if not isinstance(opt.get(key), bool):
            errors.append(f"optimization.{key} must be true or false.")
    if opt.get("start_from") not in START_FROM:
        errors.append(f"optimization.start_from must be one of {list(START_FROM)}.")
    for key, lo in (("column_stories_per_group", 1), ("max_analyses", 1)):
        v = opt.get(key)
        if not isinstance(v, int) or isinstance(v, bool) or v < lo:
            errors.append(f"optimization.{key} must be a whole number >= {lo}.")
    if opt.get("beam_series") or opt.get("column_series"):
        if not str(opt.get("section_file", "")).strip():
            errors.append("optimization.section_file is empty (e.g. AISC16.xml).")
        if not str(opt.get("steel_material", "")).strip():
            errors.append("optimization.steel_material is empty (e.g. A992Fy50).")

    return errors
