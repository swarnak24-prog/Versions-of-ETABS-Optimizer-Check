"""Flag results PASS/FAIL, print a summary, and save CSV files."""
import csv
import json
import logging
import os

log = logging.getLogger("etabs_check")

JOINT_FIELDS = ["story", "joint", "column", "joint_below", "elevation", "height",
                "drift_x", "case_x", "step_x", "drift_y", "case_y", "step_y",
                "max_drift", "limit", "ratio_to_limit", "status"]
JOINT_HEADERS = {"story": "Story", "joint": "Joint", "column": "Column below",
                 "joint_below": "Joint below", "elevation": "Elevation", "height": "Story height",
                 "drift_x": "Drift X", "case_x": "Governing case X", "step_x": "Step X",
                 "drift_y": "Drift Y", "case_y": "Governing case Y", "step_y": "Step Y",
                 "max_drift": "Max drift", "limit": "Drift limit",
                 "ratio_to_limit": "Max drift / limit", "status": "Status"}
STORY_FIELDS = ["story", "direction", "drift", "limit", "ratio_to_limit", "status",
                "case", "step", "frame", "joint", "elevation", "height"]
DESIGN_FIELDS = ["frame", "section", "ratio", "allowable", "status", "ratio_type", "combo", "message"]


def evaluate_joints(rows, limit):
    for r in rows:
        r["max_drift"] = max(r["drift_x"], r["drift_y"])
        r["limit"] = limit
        r["ratio_to_limit"] = r["max_drift"] / limit
        r["status"] = "PASS" if r["max_drift"] <= limit else "FAIL"
    return rows


def evaluate_drifts(rows, limit):
    for r in rows:
        r["limit"] = limit
        r["ratio_to_limit"] = r["drift"] / limit
        r["status"] = "PASS" if r["drift"] <= limit else "FAIL"
    return rows


def evaluate_design(rows, allowable):
    for r in rows:
        r["allowable"] = allowable
        r["status"] = "PASS" if r["ratio"] <= allowable else "FAIL"
    return rows


def write_csv(rows, path, fields, headers=None):
    """Write rows to CSV. headers maps field -> column title (defaults to the field name)."""
    headers = headers or {}
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow([headers.get(k, k) for k in fields])
        for r in rows:
            w.writerow([round(r.get(k), 6) if isinstance(r.get(k), float) else r.get(k, "")
                        for k in fields])
    log.info("Saved %s", path)


def write_joint_csv(rows, path):
    write_csv(rows, path, JOINT_FIELDS, JOINT_HEADERS)


def format_summary(joint_rows, story_rows, design_rows, limit, allowable, method):
    lines = []
    if joint_rows:
        n_fail = sum(r["status"] == "FAIL" for r in joint_rows)
        lines += [f"MF JOINT DRIFTS  (limit {limit:.4f})",
                  f"{'Story':<10}{'Joint':<8}{'Drift X':>9}{'Drift Y':>9}{'Max/Lim':>9}  {'Status':<7}{'Governing case':<20}"]
        for r in joint_rows:
            case = r["case_x"] if r["drift_x"] >= r["drift_y"] else r["case_y"]
            lines.append(f"{str(r['story']):<10}{str(r['joint']):<8}{r['drift_x']:>9.5f}{r['drift_y']:>9.5f}"
                         f"{r['ratio_to_limit']:>9.2f}  {r['status']:<7}{str(case):<20}")
        lines.append(f"-> {n_fail} of {len(joint_rows)} joints FAIL")
    else:
        n_fail = sum(r["status"] == "FAIL" for r in story_rows)
        lines += [f"STORY DRIFTS  (limit {limit:.4f}, method: {method})",
                  f"{'Story':<12}{'Dir':<5}{'Drift':>9}{'D/Limit':>9}  {'Status':<7}{'Case/Combo':<20}"]
        for r in story_rows:
            lines.append(f"{str(r['story']):<12}{r['direction']:<5}{r['drift']:>9.5f}{r['ratio_to_limit']:>9.2f}"
                         f"  {r['status']:<7}{str(r['case']):<20}")
        lines.append(f"-> {n_fail} of {len(story_rows)} story/direction checks FAIL")
    lines.append("")

    if design_rows is None:
        lines.append("STEEL DESIGN: skipped (drift-only run)")
        return "\n".join(lines)
    n_fail = sum(r["status"] == "FAIL" for r in design_rows)
    lines.append(f"STEEL DESIGN  (allowable D/C {allowable:.2f}): {len(design_rows)} members, {n_fail} FAIL")
    shown = [r for r in design_rows if r["status"] == "FAIL"]
    lines.append("Members over the allowable ratio:" if shown else "No members over the allowable ratio. Highest 10:")
    for r in shown or design_rows[:10]:
        lines.append(f"{str(r['frame']):<10}{str(r['section']):<16}{r['ratio']:>7.3f}  "
                     f"{r['status']:<7}{r['ratio_type']:<10}{str(r['combo']):<20}")
    return "\n".join(lines)


def report(joint_rows, story_rows, design_rows, settings, run_folder):
    limit = float(settings["drift"]["limit"])
    allowable = float(settings["design"]["allowable_ratio"])
    design_ran = design_rows is not None
    evaluate_joints(joint_rows, limit)
    evaluate_drifts(story_rows, limit)
    if design_ran:
        evaluate_design(design_rows, allowable)

    text = format_summary(joint_rows, story_rows, design_rows, limit, allowable, settings["drift"]["method"])
    log.info("\n%s", text)

    if joint_rows:
        write_joint_csv(joint_rows, os.path.join(run_folder, "joint_drifts.csv"))
    else:
        write_csv(story_rows, os.path.join(run_folder, "story_drifts.csv"), STORY_FIELDS)
    if design_ran:
        write_csv(design_rows, os.path.join(run_folder, "steel_design_ratios.csv"), DESIGN_FIELDS)
    with open(os.path.join(run_folder, "summary.txt"), "w", encoding="utf-8") as f:
        f.write(text + "\n")

    drift_rows = joint_rows or story_rows
    summary = {
        "drift_limit": limit,
        "drift_fail_count": sum(r["status"] == "FAIL" for r in drift_rows),
        "drift_check_count": len(drift_rows),
        "max_drift": max((r["ratio_to_limit"] * limit for r in drift_rows), default=0.0),
        "design_ran": design_ran,
        "design_fail_count": sum(r["status"] == "FAIL" for r in (design_rows or [])),
        "max_ratio": max((r["ratio"] for r in (design_rows or [])), default=0.0),
        "design_top": ({k: design_rows[0][k] for k in ("frame", "section", "ratio", "combo", "ratio_type")}
                       if design_rows else None),
        "run_folder": run_folder,
    }
    summary["overall_pass"] = summary["drift_fail_count"] == 0 and summary["design_fail_count"] == 0
    with open(os.path.join(run_folder, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    log.info("OVERALL: %s", "PASS" if summary["overall_pass"] else "FAIL")

    summary["joint_rows"] = joint_rows    # for the results window (not saved in summary.json)
    summary["story_rows"] = story_rows
    return summary
