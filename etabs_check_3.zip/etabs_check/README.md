# ETABS Model Check (step 1 of the optimizer)

Connects to ETABS, opens a **copy** of your model, runs analysis and steel frame
design, then reports story drifts and steel D/C ratios as PASS/FAIL (console + CSV).
It does not change section sizes yet.

This program talks to ETABS directly through the CSI API (COM). It does **not**
need the Claude MCP server; the MCP is what lets Claude talk to ETABS in chat.

## Files

| File | Purpose |
|---|---|
| `etabs_check.py` | Entry point: run, `--test-connection`, `--gui` |
| `etabs_api.py` | `connect`, `open_model_copy`, `set_units`, `run_analysis`, `run_steel_design`, `save_model`, `close` |
| `results.py` | `get_drifts`, `get_design_ratios` |
| `report.py` | PASS/FAIL flags, summary table, CSV files |
| `optimizer.py` | Automatic grouping, size ladders and the two-phase drift optimization loop |
| `web_server.py` | Local web server for the browser interface (`--web`) |
| `web/index.html` | The browser interface page |
| `sections.py` | Reads the ETABS AISC library, filters by selected series, imports missing shapes into the copy |
| `config.py` | Load / validate / save `settings.json` |
| `gui.py` | Tkinter settings window with Run button |
| `settings.json` | Your inputs (**JSON** was chosen: built into Python, no extra package) |

## Install

1. Use **64-bit Python** (ETABS is 64-bit). From earlier, yours is:
   `C:\Users\amy.mccall\AppData\Local\Python\pythoncore-3.14-64\python.exe`
2. Install the one dependency with that Python:
   ```
   "C:\Users\amy.mccall\AppData\Local\Python\pythoncore-3.14-64\python.exe" -m pip install comtypes
   ```
   (Tkinter, csv and json are built in.)
3. Copy this folder somewhere, e.g. `C:\ETABS-Check\`.
4. If the test connection says *"could not create the ETABS API helper"*, register
   the API once: run `RegisterETABS.exe` **as administrator** from the ETABS install
   folder (e.g. `C:\Program Files\Computers and Structures\ETABS 22\`).

Written for ETABS v18 and later (API name `ETABSv1`). ETABS 2017 and older use a
different API name and will not work without changes.

## Run

Open Command Prompt in the folder (shown with `python` for short; use your full Python path):

```
python etabs_check.py --test-connection      # connect, print ETABS version + model name
python etabs_check.py --gui                  # settings window: browse, edit, save, Run
python etabs_check.py                        # full run using settings.json
python etabs_check.py --settings other.json  # use another settings file
```

Exit codes: `0` all checks pass, `2` ran fine but something FAILS, `1` error.

## Browser interface (`--web`)

```
"C:\Users\amy.mccall\AppData\Local\Python\pythoncore-3.14-64\python.exe" etabs_check.py --web
```

Your browser opens **Lateral Frame Optimizer** at `http://127.0.0.1:8765` (this computer only).
Keep the Command Prompt window open while you use it; press Ctrl+C there to stop.

- **ETABS model** dropdown lists the `.edb` files in the model folder (type another folder
  path and click **Refresh** to change it).
- Set the criteria and click **Optimize frame**. Progress and the log show under the button.
- Results: pass/fail banner, weight and drift metrics, design check summary, story drift chart
  (as modeled vs optimized), member schedule, calculation log, 3D view colored by size change,
  and downloads of the CSV files from the run folder.
- Settings you use are saved to `settings.json`, shared with `--gui` and the command line.

The same page published on claude.ai runs in **demo mode** on a sample building, because a web
page there cannot reach ETABS on your computer.

## Settings (`settings.json`)

| Key | Meaning |
|---|---|
| `model_path` | Your original `.edb`. Never modified; it is copied into the run folder. |
| `output_folder` | Each run creates `run_YYYYMMDD_HHMMSS\` here. |
| `units` | `kip_in` or `kip_ft` |
| `attach_to_running` | `true` = use an open ETABS if there is one, otherwise start ETABS |
| `etabs_program_path` | Optional path to `ETABS.exe` (blank = latest installed) |
| `close_etabs_when_done` | Close ETABS at the end, only if this program started it |
| `drift.limit` | e.g. `0.020` |
| `drift.cases` | Load case and/or combo names to check (must match ETABS exactly) |
| `drift.lateral_group` | Group assigned to your lateral frame members, e.g. `Lateral` |
| `drift.method` | `lateral_joints` (default, see below) or `etabs_story_drifts` |
| `design.run` | GUI: **"Run steel frame design for optimization"**. With optimization on: `true` = steel design runs at **every** trial and a design must pass drift **and** D/C ≤ `allowable_ratio` (Lateral members); `false` = drift-only optimization (faster). Without optimization it simply turns steel design on/off for the check run. |
| `design.allowable_ratio` | e.g. `1.0` |
| `design.group` | Group of frames to report D/C for; `All` = every frame |
| `optimization.beam_series` | W series allowed for **beams** in the optimizer, e.g. `["W18", "W21", "W24"]` (GUI: "Beam series" checklist) |
| `optimization.column_series` | W series allowed for **columns**, e.g. `["W14"]` (GUI: "Column series" checklist) |
| `optimization.section_file` | ETABS section library to read shapes from. `AISC16.xml` usually works; if not, browse to the full path in the ETABS install folder |
| `optimization.steel_material` | Material given to imported shapes; must exist in your model, e.g. `A992Fy50` |
| `optimization.enabled` | Run the optimization loop (GUI: "Run optimization" on the Optimization tab) |
| `optimization.split_by_direction` | Separate groups for X- and Y-direction frames |
| `optimization.column_stories_per_group` | 1, 2 or 3 stories per column group (e.g. 2 for splices every two floors) |
| `optimization.start_from` | `current` (sizes in your model) or `lightest` (lightest shape in each pool) |
| `optimization.max_analyses` | Stop after this many ETABS analyses (default 50) |
| `optimization.column_depth_rule` | Column nominal depth ≥ depth of beams it supports. Off by default: MF columns (W14) are usually shallower than the beams |
| `optimization.hide_etabs` | Hide the ETABS window during the loop (faster); always shown again at the end |

## Outputs (in the run folder)

- `<model>.edb` — the analyzed and designed **copy**
- `joint_drifts.csv` — drift X and Y at every MF beam-column joint (top of each `Lateral`
  column), governing case, max drift / limit, PASS/FAIL. The same table appears in the
  **Drift Results** window after a GUI run, with an **Export CSV...** button.
- `story_drifts.csv` — written instead of `joint_drifts.csv` only for the `etabs_story_drifts` method
- `steel_design_ratios.csv` — every designed member: governing D/C, check type, combo, PASS/FAIL (only when steel design is run)
- `summary.txt`, `summary.json` — the console summary; JSON is for the future optimizer loop
- `section_pool.csv` — every beam/column shape allowed for the optimizer (lightest first) and whether it was imported or already in the model
- `optimization_groups.csv` — each group, its members, start size and final size
- `iterations.csv` — every analysis the optimizer ran: trial, sizes, weight, max drift / limit, kept or not
- `run.log` — every step and every API call, with return codes on failure

## How drifts are computed (`lateral_joints`)

1. Read all beams and columns in the `Lateral` group and collect their joints.
2. For each joint at the top of a `Lateral` column: drift = (U_joint − U_joint below) /
   column height, in X and Y, for the same case and step; keep the max over your drift cases.
3. Compare the larger of X and Y to the limit → PASS/FAIL per joint.
4. Joints on lateral beams with no lateral column below (e.g. a mid-span node) are listed
   in the log as "no drift reported".

Things to know:
- **Response spectrum cases:** displacements are already SRSS/CQC-combined, so
  subtracting them is not a true drift. For RS cases use `etabs_story_drifts`
  (ETABS' own story drift, which considers all joints at each story, not only the lateral group).
- **Envelope combos** report Max and Min separately; each is checked.
- Drifts are elastic results for the cases you choose; any Cd/Ie amplification
  must already be in those cases or applied by you.
- Joint displacements are read in joint local axes (global unless you changed them).

## API calls I'm unsure of

Check these in the CSI API help, `CSI_OAPI_Documentation.chm` in the ETABS install folder:

- **`cDesignSteel.GetSummaryResults`** — ETABS documents a long form (separate PMM,
  V-major and V-minor ratios and combos); some builds use a short SAP2000-style form.
  `results.py` tries both and reports which matched in `run.log`. If both fail, the
  argument list differs in your version.
- **`cAnalysisResults.StoryDrifts`** (only used by `etabs_story_drifts`) — argument
  order assumed: Story, LoadCase, StepType, StepNum, Direction, Drift, Label, X, Y, Z.
- **`cPropFrame.GetPropFileNameList` / `ImportProp`** — used to read the AISC library and import
  shapes. CSI says a bare file name like `AISC16.xml` is usually found, but sometimes a full
  path is needed. If the run says the library is empty, browse to the file.
- **comtypes argument style** — calls pass placeholder values (`0`, `[]`, `""`) for
  output arguments and read outputs from the returned list (return code last). This is
  the common convention, but confirm against your version if a call raises a TypeError.

## Troubleshooting

| Message | Fix |
|---|---|
| ETABS not found / could not create API helper | Install ETABS v18+, use 64-bit Python, run `RegisterETABS.exe` as admin |
| Model locked | Close the file in other programs, or check folder permissions |
| `'X' is not a load case or combination` | Fix spelling in `drift.cases` (case sensitive) |
| `Group 'Lateral' not found` | Create/assign the group in ETABS, or fix `drift.lateral_group` |
| Analysis failed: cases did not finish | Open the copy in the run folder and check the ETABS analysis log |
| Could not read steel design results | Check design combos are set in ETABS; see "API calls I'm unsure of" |

## How the optimizer works

1. **Groups (automatic):** every beam and column in the `Lateral` group is grouped by
   geometry: beams by level, columns by story (or every 2-3 stories), optionally split X / Y.
2. **Size ladders:** the selected series are sorted light to heavy, keeping only shapes that
   are stiffer (larger Ix) than every lighter shape, so each step up adds stiffness.
3. **Phase 1, reach drift:** while any MF joint exceeds the limit, each group is tried one
   size up; the change with the most drift reduction per pound is kept (or the lightest
   trial that already passes).
4. **Phase 2, lighten:** each group is tried one size down, biggest saving first; a step is
   kept only if drift still passes. Full passes repeat until nothing can get lighter.
5. **Stop:** converged, or `max_analyses` reached. The lightest passing design found is left
   assigned in the copy, then the normal final analysis, drift report and (if checked) steel
   design run on it. If nothing passes, the lowest-drift design found is kept and the
   results say so.

**Strength:** if "Run steel frame design for optimization" is checked, every trial also runs
steel design and its governing ratio is max(drift / limit, max D/C of Lateral members /
allowable). A trial passes only if both are OK. `iterations.csv` then also lists max D/C, the
member, the combo, and whether drift or strength governed. Unchecked, the loop checks drift only. The original model is never changed: everything happens in the run-folder copy.
