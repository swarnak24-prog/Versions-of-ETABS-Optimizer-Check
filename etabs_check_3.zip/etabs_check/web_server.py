"""Local web server for the browser interface (python etabs_check.py --web).

Serves web/index.html on http://127.0.0.1:8765 (this computer only) and a small JSON API
the page uses to list models, save settings, run the optimizer and read results.
ETABS work runs in a background thread; the page polls /api/status for the log and result.
"""
import json
import logging
import os
import threading
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import etabs_check as app
from config import (DRIFT_METHODS, START_FROM, UNIT_CODES, W_SERIES, SettingsError, default_settings,
                    load_settings, save_settings, validate_settings)
from optimizer import LENGTH_TO_FT
from sections import parse_w_shape

log = logging.getLogger("etabs_check")
HERE = os.path.dirname(os.path.abspath(__file__))
PAGE = os.path.join(HERE, "web", "index.html")
DOWNLOADS = {"schedule": "optimization_groups.csv", "log": "iterations.csv", "drifts": "joint_drifts.csv",
             "report": "summary.txt", "design": "steel_design_ratios.csv", "pool": "section_pool.csv",
             "runlog": "run.log"}


# ------------------------------------------------------------- job state
class Job:
    def __init__(self):
        self.lock = threading.Lock()
        self.state, self.kind = "idle", ""
        self.lines, self.result, self.error, self.run_folder = [], None, "", ""


JOB = Job()


class _ListHandler(logging.Handler):
    def emit(self, record):
        with JOB.lock:
            JOB.lines.append(self.format(record))


def _run_job(kind, settings):
    try:
        import comtypes
        comtypes.CoInitialize()
    except ImportError:
        comtypes = None
    handler = _ListHandler()
    try:
        if kind == "test":
            app.setup_logging(extra_handlers=[handler])
            version, model = app.test_connection(settings)
            result = {"test": {"version": version, "model": model}}
        else:
            summary = app.run_check(settings, extra_log_handlers=[handler])
            result = build_web_result(summary, settings)
            JOB.run_folder = summary["run_folder"]
        with JOB.lock:
            JOB.result, JOB.state = result, "done"
    except Exception as e:
        log.error("%s", e)
        with JOB.lock:
            JOB.error, JOB.state = str(e), "error"
    finally:
        if comtypes:
            comtypes.CoUninitialize()


def start_job(kind, settings):
    with JOB.lock:
        if JOB.state == "running":
            return False
        JOB.state, JOB.kind = "running", kind
        JOB.lines, JOB.result, JOB.error = [], None, ""
    threading.Thread(target=_run_job, args=(kind, settings), daemon=True).start()
    return True


# ----------------------------------------------------- result for the page
def _plf(shape):
    parsed = parse_w_shape(shape)
    return parsed[1] if parsed else 0.0


def build_web_result(summary, settings):
    """Turn a run_check summary into the compact result the page draws."""
    opt = summary.get("optimization")
    geom = summary.get("frame_geometry") or []
    k = LENGTH_TO_FT[settings["units"]]
    joints = summary.get("joint_rows") or []

    elev = {}
    for j in joints:
        e = j["elevation"] * k
        elev[j["story"]] = max(elev.get(j["story"], e), e)
    final_story = {(r["story"], r["direction"]): r["drift"] for r in summary.get("story_rows") or []}
    start_rows = (opt or {}).get("start_story_drifts") or summary.get("story_rows") or []
    start_story = {(r["story"], r["direction"]): r["drift"] for r in start_rows}
    stories = sorted(elev, key=lambda s: -elev[s])
    story_drifts = [{"story": s, "elev": round(elev[s], 3),
                     "x0": start_story.get((s, "X"), 0.0), "y0": start_story.get((s, "Y"), 0.0),
                     "x1": final_story.get((s, "X"), 0.0), "y1": final_story.get((s, "Y"), 0.0)}
                    for s in stories]

    def governing(axis):
        if not joints:
            return None
        j = max(joints, key=lambda r: r[f"drift_{axis}"])
        return {"story": j["story"], "joint": j["joint"], "value": j[f"drift_{axis}"],
                "case": j[f"case_{axis}"]}

    if opt:
        w0, w1 = opt["start_weight"] * 1000, opt["final_weight"] * 1000
        groups = []
        for g in opt["groups"]:
            groups.append({"name": g["group"], "role": g["role"], "members": g["members"],
                           "start": g["start"], "final": g["final"],
                           "changeLb": round(g["length_ft"] * (_plf(g["final"]) - _plf(g["start"])), 1)})
        history = [{"analysis": h["analysis"], "phase": h["phase"], "action": h["action"],
                    "weightLb": h["weight_kips"] * 1000, "driftRatio": h["max_drift_over_limit"],
                    "dc": h.get("max_dc"), "governs": h.get("governs", "drift"), "passes": h["passes"],
                    "accepted": h["accepted"], "sizes": {n: h[n] for n in opt["group_names"]}}
                   for h in opt["history"]]
        dc0 = opt["history"][0].get("max_dc") if opt["history"] else None
    else:
        w0 = w1 = sum(m["length_ft"] * _plf(m["final"]) for m in geom)
        by_group = {}
        for m in geom:
            g = by_group.setdefault(m["group"] or m["role"], {"name": m["group"] or m["role"], "role": m["role"],
                                                              "members": 0, "start": m["final"],
                                                              "final": m["final"], "changeLb": 0.0})
            g["members"] += 1
        groups, history, dc0 = list(by_group.values()), [], None

    return {
        "modelName": os.path.basename(settings["model_path"]), "modelPath": settings["model_path"],
        "modelCopy": summary.get("model_copy", ""), "runFolder": summary["run_folder"],
        "units": settings["units"], "driftLimit": summary["drift_limit"],
        "optimized": bool(opt), "checks": (opt or {}).get("checks", "drift"),
        "strengthChecked": bool(summary.get("design_ran")), "allowable": settings["design"]["allowable_ratio"],
        "analyses": (opt or {}).get("analyses", 1), "stopReason": (opt or {}).get("stop_reason", ""),
        "foundPassing": (opt or {}).get("found_passing", summary["overall_pass"]),
        "overallPass": summary["overall_pass"], "driftFailCount": summary["drift_fail_count"],
        "jointCount": summary["drift_check_count"],
        "weightStartLb": round(w0, 1), "weightFinalLb": round(w1, 1),
        "storyDrifts": story_drifts, "governingX": governing("x"), "governingY": governing("y"),
        "dcStart": dc0, "dcFinal": (summary.get("design_top") or {}).get("ratio"),
        "dcTop": summary.get("design_top"), "designFailCount": summary.get("design_fail_count", 0),
        "depthRule": settings["optimization"]["column_depth_rule"],
        "groups": groups, "history": history, "members": geom,
    }


# ----------------------------------------------------------------- models
def list_models(folder):
    if not folder or not os.path.isdir(folder):
        return []
    out = []
    for name in os.listdir(folder):
        if name.lower().endswith(".edb"):
            p = os.path.join(folder, name)
            out.append({"name": name, "path": p.replace("\\", "/"), "modified": os.path.getmtime(p)})
    return sorted(out, key=lambda m: -m["modified"])[:200]


# ---------------------------------------------------------------- handler
def make_handler(settings_path):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):  # keep the console quiet
            pass

        def _json(self, obj, code=200):
            body = json.dumps(obj, default=str).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def _body(self):
            n = int(self.headers.get("Content-Length") or 0)
            return json.loads(self.rfile.read(n) or b"{}")

        def _settings(self):
            try:
                return load_settings(settings_path) if os.path.isfile(settings_path) else default_settings()
            except SettingsError:
                return default_settings()

        def do_GET(self):
            url = urllib.parse.urlparse(self.path)
            q = urllib.parse.parse_qs(url.query)
            if url.path in ("/", "/index.html"):
                with open(PAGE, "rb") as f:
                    body = f.read()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            elif url.path == "/api/ping":
                self._json({"ok": True, "live": True})
            elif url.path == "/api/state":
                s = self._settings()
                folder = os.path.dirname(s["model_path"]) if s["model_path"] else ""
                self._json({"settings": s, "series": W_SERIES, "startFrom": list(START_FROM),
                            "driftMethods": list(DRIFT_METHODS), "units": list(UNIT_CODES),
                            "folder": folder.replace("\\", "/"), "models": list_models(folder),
                            "job": JOB.state})
            elif url.path == "/api/models":
                self._json({"models": list_models((q.get("folder") or [""])[0])})
            elif url.path == "/api/status":
                since = int((q.get("since") or ["0"])[0])
                with JOB.lock:
                    self._json({"state": JOB.state, "kind": JOB.kind, "lines": JOB.lines[since:],
                                "next": len(JOB.lines), "result": JOB.result if JOB.state == "done" else None,
                                "error": JOB.error})
            elif url.path == "/api/download":
                name = DOWNLOADS.get((q.get("file") or [""])[0])
                path = os.path.join(JOB.run_folder, name) if (name and JOB.run_folder) else ""
                if not path or not os.path.isfile(path):
                    self._json({"error": "That file is not in the latest run folder."}, 404)
                    return
                with open(path, "rb") as f:
                    body = f.read()
                self.send_response(200)
                self.send_header("Content-Type", "text/csv" if name.endswith(".csv") else "text/plain")
                self.send_header("Content-Disposition", f'attachment; filename="{name}"')
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            else:
                self._json({"error": "Not found"}, 404)

        def do_POST(self):
            url = urllib.parse.urlparse(self.path)
            try:
                data = self._body()
            except json.JSONDecodeError:
                self._json({"error": "Request body is not valid JSON."}, 400)
                return
            if url.path in ("/api/run", "/api/test", "/api/settings"):
                s = self._settings()
                s.update({k: v for k, v in (data.get("settings") or {}).items() if k in s})
                if url.path == "/api/test":
                    started = start_job("test", s)
                    self._json({"started": started}, 202 if started else 409)
                    return
                errors = validate_settings(s, require_model=url.path == "/api/run")
                if errors:
                    self._json({"errors": errors}, 400)
                    return
                save_settings(s, settings_path)
                if url.path == "/api/settings":
                    self._json({"saved": True})
                    return
                started = start_job("run", s)
                self._json({"started": started} if started else {"error": "A run is already in progress."},
                           202 if started else 409)
            elif url.path == "/api/open_folder":
                try:
                    os.startfile(JOB.run_folder)  # Windows only
                    self._json({"opened": True})
                except (AttributeError, OSError) as e:
                    self._json({"error": str(e)}, 400)
            else:
                self._json({"error": "Not found"}, 404)

    return Handler


def serve(settings_path, port=8765, open_browser=True):
    server = ThreadingHTTPServer(("127.0.0.1", port), make_handler(settings_path))
    url = f"http://127.0.0.1:{port}/"
    print(f"Lateral Frame Optimizer is running at {url}\nKeep this window open. Press Ctrl+C to stop.")
    if open_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("Stopped.")
    finally:
        server.server_close()
