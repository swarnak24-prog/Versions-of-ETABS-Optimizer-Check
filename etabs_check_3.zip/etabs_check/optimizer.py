"""Drift-driven member size optimization.

Design variables: groups of Lateral-group members, built automatically from geometry
(beams by level, columns by story, optionally split by frame direction X/Y).
Each group uses one W shape from an "efficient ladder": shapes sorted light -> heavy,
keeping only shapes stiffer (larger Ix) than every lighter one.

Checks: drift at every MF joint; plus, when "Run steel frame design for optimization"
is checked, steel D/C of the Lateral members at every trial (governing ratio =
max(drift / limit, D/C / allowable); a trial passes when it is <= 1.0).

Phase 1 (reach the checks): while the governing ratio exceeds 1.0, try upsizing each
  group one rung and keep the change with the best drift reduction per added weight
  (or the lightest trial that passes).
Phase 2 (lighten): step groups down one rung, largest weight saving first; keep a step
  only if all checks still pass. Repeat full passes until nothing can step down.
Stops when no lighter passing design is found or the analysis limit is reached.
The lightest passing design seen is always kept.

API calls used (cFrameObj / cPropFrame in CSI_OAPI_Documentation.chm):
  FrameObj.GetSection(Name, PropName, SAuto)      FrameObj.SetSection(Name, PropName, ItemType)
  PropFrame.GetSectProps(Name, Area, As2, As3, Torsion, I22, I33, S22, S33, Z22, Z33, R22, R33)
  cOAPI.Hide() / Unhide()
"""
import csv
import logging
import math
import os
from collections import Counter

import etabs_api as api
import results
from etabs_api import EtabsError, check, name_list
from sections import parse_w_shape

log = logging.getLogger("etabs_check")

LENGTH_TO_FT = {"kip_in": 1.0 / 12.0, "kip_ft": 1.0}
TOL = results.VERTICAL_TOL


# ======================================================== model geometry
def get_lateral_members(session, group):
    """Beams and columns in the lateral group with story, direction, length and current section."""
    m = session.model
    groups = name_list(m.GroupDef.GetNameList(0, []), "Get group names")
    if group not in groups:
        raise EtabsError(f"Group '{group}' not found in the model. Groups: {', '.join(groups)}")
    r = check(m.GroupDef.GetAssignments(group, 0, [], []), f"Get members of group '{group}'")
    frames = [r[2][i] for i in range(r[0]) if r[1][i] == results.OBJ_TYPE_FRAME]

    xyz, label = {}, {}

    def coords(p):
        if p not in xyz:
            xyz[p] = results._coords(m, p)
        return xyz[p]

    def story(p):
        if p not in label:
            label[p] = check(m.PointObj.GetLabelFromName(p, "", ""), f"Story of joint {p}")[1]
        return label[p]

    members, braces = [], []
    for f in frames:
        p = check(m.FrameObj.GetPoints(f, "", ""), f"End joints of frame {f}")
        (xi, yi, zi), (xj, yj, zj) = coords(p[0]), coords(p[1])
        dx, dy, dz = xj - xi, yj - yi, zj - zi
        horiz = math.hypot(dx, dy)
        section = check(m.FrameObj.GetSection(f, "", ""), f"Section of frame {f}")[0]
        base = {"frame": f, "section": section, "length": math.sqrt(horiz ** 2 + dz ** 2),
                "pi": (xi, yi, zi), "pj": (xj, yj, zj)}
        if abs(dz) > 0 and horiz <= TOL * abs(dz):
            top, bot = (p[1], p[0]) if zj > zi else (p[0], p[1])
            members.append({**base, "role": "column", "story": story(top), "top": top, "bottom": bot,
                            "elevation": max(zi, zj), "direction": None})
        elif abs(dz) <= TOL * horiz:
            members.append({**base, "role": "beam", "story": story(p[0]), "joints": (p[0], p[1]),
                            "elevation": (zi + zj) / 2, "direction": "X" if abs(dx) >= abs(dy) else "Y"})
        else:
            braces.append(f)
    if braces:
        log.warning("Braces in the lateral group are not resized: %s", ", ".join(braces))

    # A column's direction comes from the MF beams framing into its top joint.
    joint_dirs = {}
    for b in (x for x in members if x["role"] == "beam"):
        for j in b["joints"]:
            joint_dirs.setdefault(j, set()).add(b["direction"])
    for c in (x for x in members if x["role"] == "column"):
        dirs = joint_dirs.get(c["top"], set())
        c["direction"] = "".join(sorted(dirs)) if dirs else "X"
    return members


def build_groups(members, split_by_direction=False, column_stories_per_group=1, length_to_ft=1.0):
    """Automatic grouping: beams by level, columns by story (or N stories), optional X/Y split."""
    groups = []

    def add(name, role, mems, stories, direction):
        groups.append({"name": name, "role": role, "members": [x["frame"] for x in mems],
                       "stories": stories, "direction": direction,
                       "length_ft": sum(x["length"] for x in mems) * length_to_ft,
                       "elevation": min(x["elevation"] for x in mems),
                       "current_sections": [x["section"] for x in mems]})

    beams = {}
    for b in (x for x in members if x["role"] == "beam"):
        beams.setdefault((b["story"], b["direction"] if split_by_direction else None), []).append(b)
    for (st, d), mems in sorted(beams.items(), key=lambda kv: (min(x["elevation"] for x in kv[1]), kv[0][1] or "")):
        add(f"Beams {st}" + (f" ({d})" if d else ""), "beam", mems, [st], d)

    cols = [x for x in members if x["role"] == "column"]
    story_elev = {}
    for c in cols:
        story_elev[c["story"]] = min(story_elev.get(c["story"], c["elevation"]), c["elevation"])
    ordered = [s for s, _ in sorted(story_elev.items(), key=lambda kv: kv[1])]
    n = max(1, int(column_stories_per_group))
    chunk_of = {s: i // n for i, s in enumerate(ordered)}
    chunks = {}
    for c in cols:
        chunks.setdefault((chunk_of[c["story"]], c["direction"] if split_by_direction else None), []).append(c)
    for (ci, d), mems in sorted(chunks.items(), key=lambda kv: (kv[0][0], kv[0][1] or "")):
        stories = [s for s in ordered if chunk_of[s] == ci]
        span = stories[0] if len(stories) == 1 else f"{stories[0]}-{stories[-1]}"
        add(f"Columns {span}" + (f" ({d})" if d else ""), "column", mems, stories, d)
    return groups


# ========================================================= size ladders
def efficient_ladder(shapes):
    """shapes: [{"name","weight","I33",...}] -> lightest-first list where every rung is stiffer."""
    ladder, best_i = [], -1.0
    for s in sorted(shapes, key=lambda s: (s["weight"], -s["I33"])):
        if s["I33"] > best_i:
            ladder.append(s)
            best_i = s["I33"]
    return ladder


def section_props(session, name, cache):
    if name not in cache:
        r = check(session.model.PropFrame.GetSectProps(name, *([0.0] * 12)), f"Section properties of {name}")
        parsed = parse_w_shape(name)
        cache[name] = {"name": name, "I33": r[5], "weight": parsed[1] if parsed else None,
                       "depth": int(parsed[0][1:]) if parsed else None}
    return cache[name]


def start_index(group, ladder, props_of, start_from):
    """Rung to start from: the group's current shape (snapped up to the ladder) or the lightest."""
    if start_from == "lightest":
        return 0
    counts = Counter(group["current_sections"])
    if len(counts) > 1:
        log.warning("%s has mixed sections %s; starting from the stiffest.", group["name"], dict(counts))
    current = max(counts, key=lambda s: props_of(s)["I33"])
    names = [s["name"] for s in ladder]
    if current in names:
        return names.index(current)
    i33 = props_of(current)["I33"]
    for i, s in enumerate(ladder):
        if s["I33"] >= i33:
            log.info("%s: current %s is not on the ladder; starting at %s (next stiffer).",
                     group["name"], current, s["name"])
            return i
    log.warning("%s: current %s is stiffer than every selected shape; starting at %s.",
                group["name"], current, ladder[-1]["name"])
    return len(ladder) - 1


def depth_rule(groups, ladders):
    """Returns allowed(assignment): column nominal depth >= depth of beams at the levels it supports."""
    pairs = []
    for ci, cg in enumerate(groups):
        if cg["role"] != "column":
            continue
        for bi, bg in enumerate(groups):
            if bg["role"] == "beam" and set(bg["stories"]) & set(cg["stories"]) and \
                    (bg["direction"] is None or cg["direction"] is None or bg["direction"] in cg["direction"]):
                pairs.append((ci, bi))

    def allowed(a):
        return all(ladders[ci][a[ci]]["depth"] >= ladders[bi][a[bi]]["depth"] for ci, bi in pairs)
    return allowed


# ============================================================ the search
class _BudgetReached(Exception):
    pass


def optimize(ladder_sizes, start, evaluate, weight, allowed=lambda a: True, max_analyses=50, names=None,
             checks="drift"):
    """Two-phase discrete search. Pure Python.

    evaluate(a) returns the governing ratio (<= 1.0 passes): max drift / limit, or when strength
    is checked max(drift / limit, D/C / allowable). It may also return (ratio, details_dict).

    a (assignment) is a tuple of rung indices, one per group.
    Returns {"best", "best_ratio", "current", "history", "analyses", "stop_reason"}.
    """
    n = len(ladder_sizes)
    names = names or [f"group {i + 1}" for i in range(n)]
    cache, history = {}, []

    def ev(a, phase, action):
        if a in cache:
            return cache[a]
        if len(history) >= max_analyses:
            raise _BudgetReached
        out = evaluate(a)
        ratio, details = out if isinstance(out, tuple) else (out, {})
        cache[a] = ratio
        history.append({"analysis": len(history) + 1, "phase": phase, "action": action, "assignment": a,
                        "weight": weight(a), "max_ratio": ratio, "passes": ratio <= 1.0, "accepted": False,
                        **details})
        extra = "".join(f", {k} {v:.3f}" for k, v in details.items() if isinstance(v, float))
        log.info("Analysis %d [%s] %s: weight %.2f k%s -> %s", len(history), phase, action, weight(a),
                 extra or f", governing ratio {ratio:.3f}", "PASS" if ratio <= 1.0 else "FAIL")
        return ratio

    def accept(a):
        for h in reversed(history):
            if h["assignment"] == a:
                h["accepted"] = True
                break

    def step(a, g, d):
        return a[:g] + (a[g] + d,) + a[g + 1:]

    cur = tuple(start)
    stop = ""
    try:
        r = ev(cur, "start", "starting sizes")
        accept(cur)
        if not allowed(cur):
            log.warning("Starting sizes break the column depth rule; the search will still continue.")

        # Phase 1: upsize until all checks pass
        while r > 1.0:
            trials = []
            for g in range(n):
                if cur[g] + 1 < ladder_sizes[g] and allowed(step(cur, g, +1)):
                    t = step(cur, g, +1)
                    trials.append((g, t, ev(t, "1-upsize", f"upsize {names[g]}")))
            if not trials:
                blocked = any(cur[g] + 1 < ladder_sizes[g] for g in range(n))
                stop = (f"{checks.capitalize()} limits cannot be met: the column depth rule blocks every upsize "
                        "(turn the rule off or select deeper column series)." if blocked else
                        f"{checks.capitalize()} limits cannot be met: every group is at the largest selected shape.")
                break
            passing = [x for x in trials if x[2] <= 1.0]
            if passing:
                g, t, rt = min(passing, key=lambda x: weight(x[1]))
            else:
                g, t, rt = max(trials, key=lambda x: (r - x[2]) / max(weight(x[1]) - weight(cur), 1e-6))
            cur, r = t, rt
            accept(cur)

        # Phase 2: lighten while all checks still pass
        if r <= 1.0:
            improved = True
            while improved:
                improved = False
                order = sorted((g for g in range(n) if cur[g] > 0),
                               key=lambda g: weight(cur) - weight(step(cur, g, -1)), reverse=True)
                for g in order:
                    if cur[g] == 0 or not allowed(step(cur, g, -1)):
                        continue
                    t = step(cur, g, -1)
                    rt = ev(t, "2-lighten", f"downsize {names[g]}")
                    if rt <= 1.0:
                        cur, r = t, rt
                        accept(cur)
                        improved = True
            stop = f"Converged: no lighter design passes {checks}."
    except _BudgetReached:
        stop = f"Reached the maximum of {max_analyses} analyses."

    feasible = [(weight(a), a) for a, ratio in cache.items() if ratio <= 1.0 and allowed(a)]
    best = min(feasible)[1] if feasible else None
    least_drift = min(cache, key=lambda a: (round(cache[a], 6), weight(a))) if cache else cur
    return {"best": best, "best_ratio": cache.get(best), "current": cur, "least_drift": least_drift,
            "history": history,
            "analyses": len(history), "stop_reason": stop}


# ===================================================== ETABS integration
def run_optimization(session, settings, pools, run_folder):
    """Resize the lateral groups in the open model copy. Leaves the best design assigned."""
    opt, drift = settings["optimization"], settings["drift"]
    units = settings["units"]
    m = session.model
    api.set_units(session, units)

    members = get_lateral_members(session, drift["lateral_group"])
    groups = build_groups(members, opt["split_by_direction"], opt["column_stories_per_group"],
                          LENGTH_TO_FT[units])
    if not groups:
        raise EtabsError(f"No beams or columns found in group '{drift['lateral_group']}'.")
    log.info("Optimization groups (%d): %s", len(groups), "; ".join(
        f"{g['name']} [{len(g['members'])}]" for g in groups))

    cache = {}
    props_of = lambda name: section_props(session, name, cache)
    ladders_by_role = {}
    for role in ("beam", "column"):
        if any(g["role"] == role for g in groups):
            names = (pools or {}).get(role) or []
            if not names:
                raise EtabsError(f"No {role} shapes available. Select {role} series on the Optimization tab.")
            ladders_by_role[role] = efficient_ladder([props_of(nm) for nm in names])
            lad = ladders_by_role[role]
            log.info("%s ladder: %d efficient shapes (%s ... %s) from %d selected.", role.capitalize(),
                     len(lad), lad[0]["name"], lad[-1]["name"], len(names))
    ladders = [ladders_by_role[g["role"]] for g in groups]
    start = tuple(start_index(g, ladders[i], props_of, opt["start_from"]) for i, g in enumerate(groups))

    def weight(a):  # kips
        return sum(g["length_ft"] * ladders[i][a[i]]["weight"] for i, g in enumerate(groups)) / 1000.0

    allowed = depth_rule(groups, ladders) if opt["column_depth_rule"] else (lambda a: True)
    assigned = [None] * len(groups)

    def assign(a):
        if m.GetModelIsLocked():
            check(m.SetModelIsLocked(False), "Unlock model to change sections")
        for i, g in enumerate(groups):
            shape = ladders[i][a[i]]["name"]
            if assigned[i] != shape:
                for f in g["members"]:
                    check(m.FrameObj.SetSection(f, shape, 0), f"Assign {shape} to frame {f}")
                assigned[i] = shape

    limit = float(drift["limit"])
    check_strength = bool(settings["design"]["run"])
    allowable = float(settings["design"]["allowable_ratio"])
    checks = "drift and strength" if check_strength else "drift"
    as_modeled = {}

    def evaluate(a):
        assign(a)
        api.run_analysis(session, drift["cases"])
        joints = results.get_joint_drifts(session, drift["cases"], drift["lateral_group"])
        if "joints" not in as_modeled:  # first analysis = the sizes as modeled
            as_modeled["joints"] = joints
        drift_ratio = max((max(j["drift_x"], j["drift_y"]) for j in joints), default=0.0) / limit
        details = {"drift/limit": drift_ratio}
        if not check_strength:
            return drift_ratio, details
        # Strength: steel design on this trial, D/C of the members being resized (Lateral group)
        api.run_steel_design(session)
        rows = results.get_design_ratios(session, drift["lateral_group"])
        if not rows:
            log.warning("Steel design returned no results for group '%s'; strength not checked.",
                        drift["lateral_group"])
        top = rows[0] if rows else {"ratio": 0.0, "frame": "", "combo": ""}  # rows are sorted highest first
        details.update({"max D/C": float(top["ratio"]), "D/C member": top["frame"], "D/C combo": top["combo"]})
        return max(drift_ratio, top["ratio"] / allowable), details

    hidden = False
    if opt["hide_etabs"]:
        try:
            hidden = api.ret_code(session.etabs.Hide()) == 0
        except Exception as e:
            log.debug("Could not hide ETABS: %s", e)
    try:
        log.info("Starting optimization for %s (max %d analyses) ...", checks, opt["max_analyses"])
        res = optimize([len(l) for l in ladders], start, evaluate, weight, allowed, int(opt["max_analyses"]),
                       [g["name"] for g in groups], checks)
    finally:
        if hidden:
            try:
                session.etabs.Unhide()
            except Exception:
                pass

    final = res["best"]
    if final is None:
        final = res["least_drift"]
        log.warning("No design met the %s limits. Keeping the design with the lowest governing ratio "
                    "found; select deeper/heavier series or raise the analysis limit.", checks)
    assign(final)
    log.info("Optimization finished: %s", res["stop_reason"])

    group_rows = [{"group": g["name"], "role": g["role"], "members": len(g["members"]),
                   "member_names": " ".join(g["members"]), "length_ft": round(g["length_ft"], 2),
                   "start": ladders[i][start[i]]["name"], "final": ladders[i][final[i]]["name"]}
                  for i, g in enumerate(groups)]
    history_rows = []
    for h in res["history"]:
        row = {k: h[k] for k in ("analysis", "phase", "action", "passes", "accepted")}
        row["weight_kips"] = round(h["weight"], 3)
        row["max_drift_over_limit"] = round(h["drift/limit"], 4)
        row["max_drift"] = round(h["drift/limit"] * limit, 6)
        if check_strength:
            row["max_dc"] = round(h["max D/C"], 3)
            row["dc_member"] = h["D/C member"]
            row["dc_combo"] = h["D/C combo"]
            row["governs"] = "drift" if h["drift/limit"] >= h["max D/C"] / allowable else "strength"
        for i, g in enumerate(groups):
            row[g["name"]] = ladders[i][h["assignment"][i]]["name"]
        history_rows.append(row)

    _write_csv(os.path.join(run_folder, "optimization_groups.csv"), group_rows)
    _write_csv(os.path.join(run_folder, "iterations.csv"), history_rows)

    summary = {"stop_reason": res["stop_reason"], "analyses": res["analyses"], "checks": checks,
               "strength_checked": check_strength, "allowable_ratio": allowable,
               "found_passing": res["best"] is not None,
               "start_weight": round(weight(start), 3), "final_weight": round(weight(final), 3),
               "groups": group_rows, "history": history_rows, "group_names": [g["name"] for g in groups],
               "start_story_drifts": results.story_max_from_joints(as_modeled.get("joints", []))}
    log.info("Frame weight: %.2f k -> %.2f k after %d analyses.",
             summary["start_weight"], summary["final_weight"], summary["analyses"])
    return summary


def frame_geometry(session, settings, opt_summary=None):
    """Lateral members with coordinates (ft), group, as-modeled and current sizes, for the web viewer."""
    units = settings["units"]
    k = LENGTH_TO_FT[units]
    opt = settings["optimization"]
    members = get_lateral_members(session, settings["drift"]["lateral_group"])
    start_of, group_of = {}, {}
    if opt_summary:
        for g in opt_summary["groups"]:
            for f in g["member_names"].split():
                start_of[f], group_of[f] = g["start"], g["group"]
    else:
        for g in build_groups(members, opt["split_by_direction"], opt["column_stories_per_group"], k):
            for f in g["members"]:
                group_of[f] = g["name"]
    out = []
    for mbr in members:
        out.append({"frame": mbr["frame"], "role": mbr["role"], "story": mbr["story"],
                    "direction": mbr["direction"], "group": group_of.get(mbr["frame"], ""),
                    "i": [round(c * k, 4) for c in mbr["pi"]], "j": [round(c * k, 4) for c in mbr["pj"]],
                    "length_ft": round(mbr["length"] * k, 4),
                    "start": start_of.get(mbr["frame"], mbr["section"]), "final": mbr["section"]})
    return out


def _write_csv(path, rows):
    if not rows:
        return
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    log.info("Saved %s", path)
