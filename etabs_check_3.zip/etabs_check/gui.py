"""Tkinter window: edit settings, save them, test the connection, and run the check."""
import json
import logging
import logging.handlers
import os
import queue
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk

import etabs_check as app
import report
from config import (DRIFT_METHODS, START_FROM, UNIT_CODES, W_SERIES, SettingsError, default_settings,
                    load_settings, save_settings, validate_settings)

log = logging.getLogger("etabs_check")


class App(tk.Tk):
    def __init__(self, settings_path):
        super().__init__()
        self.title("ETABS Model Check")
        self.geometry("860x800")
        self.settings_path = settings_path
        self.settings = default_settings()
        self.log_queue = queue.Queue()
        self.result_queue = queue.Queue()
        self.queue_handler = logging.handlers.QueueHandler(self.log_queue)
        self.vars = {}
        self._build()
        self.load()
        self.after(100, self._poll)

    # ------------------------------------------------------------ layout
    def _build(self):
        tabs = ttk.Notebook(self)
        tabs.pack(fill="x", padx=10, pady=(10, 0))
        model_tab = ttk.Frame(tabs, padding=10)
        opt_tab = ttk.Frame(tabs, padding=10)
        tabs.add(model_tab, text="Model & drift")
        tabs.add(opt_tab, text="Optimization")
        rows = {}

        def add(parent, label, key, widget=None, browse=None):
            row = rows.setdefault(parent, 0)
            parent.columnconfigure(1, weight=1)
            ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=2, padx=(0, 8))
            var = tk.StringVar()
            self.vars[key] = var
            w = widget(parent, var) if widget else ttk.Entry(parent, textvariable=var)
            w.grid(row=row, column=1, sticky="ew", pady=2)
            if browse:
                ttk.Button(parent, text="Browse...", command=browse).grid(row=row, column=2, padx=4)
            rows[parent] = row + 1
            return w

        def check_box(parent, text, var):
            row = rows.setdefault(parent, 0)
            ttk.Checkbutton(parent, text=text, variable=var).grid(row=row, column=1, sticky="w", pady=1)
            rows[parent] = row + 1

        def widget_row(parent, label, widget):
            row = rows.setdefault(parent, 0)
            ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=2, padx=(0, 8))
            widget.grid(row=row, column=1, sticky="ew", pady=2)
            rows[parent] = row + 1

        combo = lambda values: (lambda parent, var: ttk.Combobox(parent, textvariable=var,
                                                                values=values, state="readonly"))
        # ---- Model & drift tab
        f = model_tab
        add(f, "Model file (.edb)", "model_path", browse=self.browse_model)
        add(f, "Output folder", "output_folder", browse=self.browse_output)
        add(f, "Units", "units", combo(list(UNIT_CODES)))
        add(f, "Drift limit (e.g. 0.020)", "drift_limit")
        add(f, "Drift cases/combos (comma separated)", "drift_cases")
        add(f, "Lateral group name", "lateral_group")
        add(f, "Drift method", "drift_method", combo(list(DRIFT_METHODS)))
        add(f, "Allowable D/C ratio", "allowable_ratio")
        add(f, "Design group (All = every frame)", "design_group")
        self.attach_var = tk.BooleanVar()
        self.close_var = tk.BooleanVar()
        self.design_var = tk.BooleanVar()
        check_box(f, "Run steel frame design for optimization", self.design_var)
        check_box(f, "Attach to running ETABS if open", self.attach_var)
        check_box(f, "Close ETABS when done (only if this program started it)", self.close_var)

        # ---- Optimization tab
        f = opt_tab
        self.opt_enabled_var = tk.BooleanVar()
        row = rows.setdefault(f, 0)
        ttk.Checkbutton(f, text="Run optimization (resize MF beams and columns for drift, lightest design)",
                        variable=self.opt_enabled_var).grid(row=row, column=0, columnspan=3, sticky="w", pady=(0, 6))
        rows[f] = row + 1
        self.beam_series = SeriesDropdown(f, W_SERIES, "Beam series")
        widget_row(f, "Beam series", self.beam_series)
        self.column_series = SeriesDropdown(f, W_SERIES, "Column series")
        widget_row(f, "Column series", self.column_series)
        add(f, "Section library file", "section_file", browse=self.browse_section_file)
        add(f, "Steel material for imported shapes", "steel_material")
        add(f, "Column stories per group", "column_stories_per_group", combo(["1", "2", "3"]))
        add(f, "Start from", "start_from", combo(list(START_FROM)))
        add(f, "Maximum analyses", "max_analyses")
        self.split_var = tk.BooleanVar()
        self.depth_rule_var = tk.BooleanVar()
        self.hide_var = tk.BooleanVar()
        check_box(f, "Split groups by frame direction (X / Y)", self.split_var)
        check_box(f, "Require column depth >= beam depth (nominal)", self.depth_rule_var)
        check_box(f, "Hide ETABS window during optimization (faster)", self.hide_var)
        row = rows[f]
        ttk.Label(f, foreground="#555", text="Groups are automatic: MF beams by level, MF columns by story, "
                  "from the Lateral group.\n\"Run steel frame design for optimization\" (Model & drift tab): "
                  "checked = every trial must pass drift AND D/C;\nunchecked = drift only (faster).",
                  ).grid(row=row, column=0, columnspan=3, sticky="w", pady=(8, 0))

        buttons = ttk.Frame(self, padding=(10, 0))
        buttons.pack(fill="x")
        self.button_widgets = []
        for text, cmd in (("Load settings", self.load), ("Save settings", self.save),
                          ("Test connection", self.test_connection), ("Run", self.run)):
            b = ttk.Button(buttons, text=text, command=cmd)
            b.pack(side="left", padx=4, pady=8)
            self.button_widgets.append(b)

        self.log_box = scrolledtext.ScrolledText(self, height=14, font=("Consolas", 9), state="disabled")
        self.log_box.pack(fill="both", expand=True, padx=10, pady=(0, 10))

    # ------------------------------------------------- settings <-> form
    def browse_model(self):
        path = filedialog.askopenfilename(title="Select ETABS model",
                                          filetypes=[("ETABS model", "*.edb"), ("All files", "*.*")])
        if path:
            self.vars["model_path"].set(path)

    def browse_section_file(self):
        path = filedialog.askopenfilename(
            title="Select ETABS section library (e.g. AISC16.xml in the ETABS folder)",
            initialdir=r"C:\Program Files\Computers and Structures",
            filetypes=[("Section library", "*.xml *.pro"), ("All files", "*.*")])
        if path:
            self.vars["section_file"].set(path)

    def browse_output(self):
        path = filedialog.askdirectory(title="Select output folder")
        if path:
            self.vars["output_folder"].set(path)

    def to_form(self, s):
        v = self.vars
        v["model_path"].set(s["model_path"])
        v["output_folder"].set(s["output_folder"])
        v["units"].set(s["units"])
        v["drift_limit"].set(str(s["drift"]["limit"]))
        v["drift_cases"].set(", ".join(s["drift"]["cases"]))
        v["lateral_group"].set(s["drift"]["lateral_group"])
        v["drift_method"].set(s["drift"]["method"])
        v["allowable_ratio"].set(str(s["design"]["allowable_ratio"]))
        v["design_group"].set(s["design"]["group"])
        self.attach_var.set(bool(s["attach_to_running"]))
        self.close_var.set(bool(s["close_etabs_when_done"]))
        self.design_var.set(bool(s["design"]["run"]))
        opt = s["optimization"]
        self.beam_series.set(opt["beam_series"])
        self.column_series.set(opt["column_series"])
        v["section_file"].set(opt["section_file"])
        v["steel_material"].set(opt["steel_material"])
        self.opt_enabled_var.set(bool(opt["enabled"]))
        self.split_var.set(bool(opt["split_by_direction"]))
        self.depth_rule_var.set(bool(opt["column_depth_rule"]))
        self.hide_var.set(bool(opt["hide_etabs"]))
        v["column_stories_per_group"].set(str(opt["column_stories_per_group"]))
        v["start_from"].set(opt["start_from"])
        v["max_analyses"].set(str(opt["max_analyses"]))

    def from_form(self):
        """Build a settings dict from the form. Raises SettingsError on unparseable input."""
        v = self.vars
        s = json.loads(json.dumps(self.settings))  # keep keys the form doesn't show
        s["model_path"] = v["model_path"].get().strip()
        s["output_folder"] = v["output_folder"].get().strip()
        s["units"] = v["units"].get()
        s["attach_to_running"] = self.attach_var.get()
        s["close_etabs_when_done"] = self.close_var.get()
        try:
            s["drift"]["limit"] = float(v["drift_limit"].get())
            s["design"]["allowable_ratio"] = float(v["allowable_ratio"].get())
        except ValueError:
            raise SettingsError("Drift limit and allowable ratio must be numbers.")
        s["drift"]["cases"] = [c.strip() for c in v["drift_cases"].get().split(",") if c.strip()]
        s["drift"]["lateral_group"] = v["lateral_group"].get().strip()
        s["drift"]["method"] = v["drift_method"].get()
        s["design"]["group"] = v["design_group"].get().strip()
        s["design"]["run"] = self.design_var.get()
        s.pop("frame_groups", None)  # replaced by the optimization series below
        try:
            max_analyses = int(v["max_analyses"].get())
        except ValueError:
            raise SettingsError("Maximum analyses must be a whole number.")
        s["optimization"] = {"beam_series": self.beam_series.get(),
                             "column_series": self.column_series.get(),
                             "section_file": v["section_file"].get().strip(),
                             "steel_material": v["steel_material"].get().strip(),
                             "enabled": self.opt_enabled_var.get(),
                             "split_by_direction": self.split_var.get(),
                             "column_stories_per_group": int(v["column_stories_per_group"].get() or 1),
                             "start_from": v["start_from"].get() or "current",
                             "max_analyses": max_analyses,
                             "column_depth_rule": self.depth_rule_var.get(),
                             "hide_etabs": self.hide_var.get()}
        return s

    def load(self):
        try:
            if os.path.isfile(self.settings_path):
                self.settings = load_settings(self.settings_path)
                self._write(f"Loaded {self.settings_path}")
            else:
                self._write(f"No settings file yet; using defaults ({self.settings_path} will be created on save).")
        except SettingsError as e:
            messagebox.showerror("Settings", str(e))
        self.to_form(self.settings)

    def save(self, quiet=False):
        try:
            s = self.from_form()
        except SettingsError as e:
            messagebox.showerror("Settings", str(e))
            return None
        save_settings(s, self.settings_path)
        self.settings = s
        if not quiet:
            self._write(f"Saved {self.settings_path}")
        return s

    # ------------------------------------------------------------ actions
    def test_connection(self):
        s = self.save(quiet=True)
        if s is not None:
            self._start(lambda: (app.setup_logging(extra_handlers=[self.queue_handler]),
                                 app.test_connection(s)))

    def run(self):
        s = self.save(quiet=True)
        if s is None:
            return
        errors = validate_settings(s)
        if errors:
            messagebox.showerror("Settings", "\n".join(errors))
            return
        self._write("Settings saved. Starting run ...")
        self._start(lambda: app.run_check(s, extra_log_handlers=[self.queue_handler]))

    def _start(self, job):
        for b in self.button_widgets:
            b.state(["disabled"])

        def worker():
            try:
                import comtypes
                comtypes.CoInitialize()  # COM must be initialized on this thread
            except ImportError:
                self.result_queue.put(("error", "comtypes is not installed (python -m pip install comtypes)."))
                return
            try:
                self.result_queue.put(("done", job()))
            except Exception as e:
                log.error("%s", e)
                self.result_queue.put(("error", str(e)))
            finally:
                comtypes.CoUninitialize()

        threading.Thread(target=worker, daemon=True).start()

    # ----------------------------------------------------------- plumbing
    def _write(self, text):
        self.log_box.configure(state="normal")
        self.log_box.insert("end", text + "\n")
        self.log_box.see("end")
        self.log_box.configure(state="disabled")

    def _poll(self):
        while not self.log_queue.empty():
            self._write(self.log_queue.get().getMessage())
        while not self.result_queue.empty():
            kind, value = self.result_queue.get()
            for b in self.button_widgets:
                b.state(["!disabled"])
            if kind == "error":
                messagebox.showerror("ETABS check", value)
            elif isinstance(value, dict) and "overall_pass" in value:
                ResultsWindow(self, value)
        self.after(100, self._poll)


class SeriesDropdown(ttk.Frame):
    """A button that drops down a checklist of series; shows the current selection."""

    def __init__(self, parent, options, title):
        super().__init__(parent)
        self.options, self.title = options, title
        self.vars = {o: tk.BooleanVar() for o in options}
        self.popup = None
        self.button = ttk.Button(self, command=self.toggle)
        self.button.pack(fill="x")
        self._refresh()

    def get(self):
        return [o for o in self.options if self.vars[o].get()]

    def set(self, values):
        for o, var in self.vars.items():
            var.set(o in values)
        self._refresh()

    def _refresh(self):
        sel = self.get()
        text = ", ".join(sel) if sel else "(none selected)"
        if len(text) > 60:
            text = f"{len(sel)} series: {sel[0]} ... {sel[-1]}"
        self.button.configure(text=f"{text}   ▾")

    def toggle(self):
        if self.popup is not None and self.popup.winfo_exists():
            self.close()
            return
        p = tk.Toplevel(self)
        p.title(self.title)
        p.transient(self.winfo_toplevel())
        p.resizable(False, False)
        p.geometry(f"+{self.button.winfo_rootx()}+{self.button.winfo_rooty() + self.button.winfo_height()}")
        p.protocol("WM_DELETE_WINDOW", self.close)
        box = ttk.Frame(p, padding=10)
        box.pack(fill="both")
        per_col = 6
        for i, o in enumerate(self.options):
            ttk.Checkbutton(box, text=o, variable=self.vars[o], command=self._refresh
                            ).grid(row=i % per_col, column=i // per_col, sticky="w", padx=6, pady=1)
        bar = ttk.Frame(p, padding=(10, 0, 10, 10))
        bar.pack(fill="x")
        ttk.Button(bar, text="All", command=lambda: self.set(self.options)).pack(side="left")
        ttk.Button(bar, text="None", command=lambda: self.set([])).pack(side="left", padx=4)
        ttk.Button(bar, text="Done", command=self.close).pack(side="right")
        self.popup = p

    def close(self):
        if self.popup is not None and self.popup.winfo_exists():
            self.popup.destroy()
        self.popup = None
        self._refresh()


class ResultsWindow(tk.Toplevel):
    """Drift at each MF joint (PASS/FAIL) and, if run, the optimization summary and history."""

    COLUMNS = (("story", "Story", 90), ("joint", "Joint", 70), ("column", "Column below", 95),
               ("drift_x", "Drift X", 85), ("case_x", "Case X", 110),
               ("drift_y", "Drift Y", 85), ("case_y", "Case Y", 110),
               ("ratio_to_limit", "Max / Limit", 85), ("status", "Status", 70))

    def __init__(self, parent, summary):
        super().__init__(parent)
        self.title("Results")
        self.geometry("980x620")
        self.summary = summary
        self.rows = summary["joint_rows"]
        limit = summary["drift_limit"]
        opt = summary.get("optimization")

        n_fail, n = summary["drift_fail_count"], summary["drift_check_count"]
        verdict = "ALL JOINTS PASS DRIFT" if n_fail == 0 else f"{n_fail} OF {n} JOINTS FAIL DRIFT"
        head = ttk.Frame(self, padding=10)
        head.pack(fill="x")
        ttk.Label(head, text=verdict, font=("Segoe UI", 14, "bold"),
                  foreground="#1a7f37" if n_fail == 0 else "#c62828").pack(anchor="w")
        ttk.Label(head, text=f"Drift limit {limit:.4f}   |   Max drift {summary['max_drift']:.5f}"
                             f"   |   Results folder: {summary['run_folder']}").pack(anchor="w")
        if opt:
            saved = opt["start_weight"] - opt["final_weight"]
            pct = 100 * saved / opt["start_weight"] if opt["start_weight"] else 0
            ttk.Label(head, text=f"Optimized MF weight: {opt['start_weight']:.2f} k -> {opt['final_weight']:.2f} k "
                                 f"({'-' if saved >= 0 else '+'}{abs(pct):.1f}%) in {opt['analyses']} analyses, checking "
                                 f"{opt.get('checks', 'drift')}. "
                                 f"{opt['stop_reason']}").pack(anchor="w")
        if summary.get("design_ran"):
            ttk.Label(head, text=f"Steel design: {summary['design_fail_count']} member(s) over the allowable "
                                 f"D/C (max {summary['max_ratio']:.2f}) - see steel_design_ratios.csv").pack(anchor="w")

        tabs = ttk.Notebook(self)
        tabs.pack(fill="both", expand=True, padx=10)
        drift_tab = ttk.Frame(tabs, padding=(0, 6))
        tabs.add(drift_tab, text="Joint drifts")
        if not self.rows:
            ttk.Label(drift_tab, text="No joint-level results: the 'etabs_story_drifts' method reports "
                                      "per story only. Switch Drift method to 'lateral_joints' to see MF joints.",
                      wraplength=900).pack(anchor="w", pady=20)
        else:
            self._table(drift_tab, self.COLUMNS, [(
                r["story"], r["joint"], r["column"], f"{r['drift_x']:.5f}", r["case_x"],
                f"{r['drift_y']:.5f}", r["case_y"], f"{r['ratio_to_limit']:.2f}", r["status"])
                for r in self.rows], [r["status"] for r in self.rows])

        if opt:
            opt_tab = ttk.Frame(tabs, padding=(0, 6))
            tabs.add(opt_tab, text="Optimization")
            ttk.Label(opt_tab, text="Final sizes by group", font=("Segoe UI", 9, "bold")).pack(anchor="w")
            group_cols = (("group", "Group", 220), ("role", "Type", 70), ("members", "Members", 70),
                          ("start", "Start size", 110), ("final", "Final size", 110))
            self._table(opt_tab, group_cols, [(g["group"], g["role"], g["members"], g["start"], g["final"])
                                              for g in opt["groups"]],
                        ["CHANGED" if g["start"] != g["final"] else "" for g in opt["groups"]], height=6)
            ttk.Label(opt_tab, text="Every analysis (green = kept)", font=("Segoe UI", 9, "bold")
                      ).pack(anchor="w", pady=(8, 0))
            hist_cols = (("analysis", "#", 40), ("phase", "Phase", 90), ("action", "Trial", 210),
                         ("weight", "Weight (k)", 85), ("ratio", "Max drift / limit", 115),
                         ("passes", "Result", 60))
            strength = opt.get("strength_checked")
            if strength:
                hist_cols += (("dc", "Max D/C", 70), ("dcm", "D/C member", 85), ("gov", "Governs", 75))
            hist_cols += tuple((f"g{i}", name, 110) for i, name in enumerate(opt["group_names"]))
            self._table(opt_tab, hist_cols, [(
                h["analysis"], h["phase"], h["action"], f"{h['weight_kips']:.2f}",
                f"{h['max_drift_over_limit']:.3f}", "PASS" if h["passes"] else "FAIL",
                *((f"{h['max_dc']:.3f}", h["dc_member"], h["governs"]) if strength else ()),
                *[h[name] for name in opt["group_names"]]) for h in opt["history"]],
                ["KEPT" if h["accepted"] else "" for h in opt["history"]], horizontal=True)

        buttons = ttk.Frame(self, padding=10)
        buttons.pack(fill="x")
        ttk.Button(buttons, text="Export joint drifts CSV...", command=self.export,
                   state="normal" if self.rows else "disabled").pack(side="left", padx=4)
        ttk.Button(buttons, text="Open results folder", command=self.open_folder).pack(side="left", padx=4)
        ttk.Button(buttons, text="Close", command=self.destroy).pack(side="right", padx=4)

    @staticmethod
    def _table(parent, columns, values, tags, height=None, horizontal=False):
        frame = ttk.Frame(parent)
        frame.pack(fill="both", expand=height is None)
        tree = ttk.Treeview(frame, columns=[c[0] for c in columns], show="headings",
                            **({"height": height} if height else {}))
        for key, title, width in columns:
            tree.heading(key, text=title)
            tree.column(key, width=width, anchor="center", stretch=not horizontal)
        tree.tag_configure("FAIL", background="#fde2e2", foreground="#9b1c1c")
        tree.tag_configure("KEPT", background="#e3f4e8")
        tree.tag_configure("CHANGED", background="#eef3fb")
        for vals, tag in zip(values, tags):
            tree.insert("", "end", values=vals, tags=(tag,) if tag else ())
        ys = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=ys.set)
        if horizontal:
            xs = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
            tree.configure(xscrollcommand=xs.set)
            xs.pack(side="bottom", fill="x")
        tree.pack(side="left", fill="both", expand=True)
        ys.pack(side="right", fill="y")
        return tree

    def export(self):
        path = filedialog.asksaveasfilename(parent=self, title="Export joint drifts",
                                            defaultextension=".csv", initialfile="joint_drifts.csv",
                                            initialdir=self.summary["run_folder"],
                                            filetypes=[("CSV file", "*.csv")])
        if path:
            try:
                report.write_joint_csv(self.rows, path)
                messagebox.showinfo("Export", f"Saved:\n{path}", parent=self)
            except PermissionError:
                messagebox.showerror("Export", "Could not save; is that file open in Excel?", parent=self)

    def open_folder(self):
        try:
            os.startfile(self.summary["run_folder"])  # Windows only
        except (AttributeError, OSError) as e:
            messagebox.showerror("Open folder", str(e), parent=self)


def launch(settings_path):
    App(settings_path).mainloop()


if __name__ == "__main__":
    launch(app.DEFAULT_SETTINGS_PATH)
